package kr.co.koitt.approval;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;


@Service
public class ApprovalService {
	
	@Autowired
	ApprovalDAO dao;

	public List<ApprovalVO> selectTeacher() {
		List<ApprovalVO> approvalList = null;
		approvalList = dao.selectTeacher();
		return approvalList;
	}//selectTeacher

	public List<ApprovalVO> selectDetail() {
		List<ApprovalVO> detailList = null;
		detailList = dao.selectDetail();
		return detailList;
	}//selectDetail

}
