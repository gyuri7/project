package kr.co.koitt.admin;

import org.apache.ibatis.session.SqlSession;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

@Repository
public class AdminLoginDAO {

	@Autowired
	SqlSession sqlSession;
	
	public int loginPro(AdminVO vo) {
		int cnt = 0;
		cnt = sqlSession.selectOne("AdminMapper.loginPro",vo);
		return cnt;
	}//loginPro

}
