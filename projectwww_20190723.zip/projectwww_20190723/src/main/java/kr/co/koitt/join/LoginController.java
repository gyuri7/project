package kr.co.koitt.join;

import java.io.PrintWriter;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;

import org.apache.ibatis.session.SqlSession;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;

import kr.co.koitt.exam.ExamVO;

@Controller
public class LoginController {
	
	private static final Logger logger = LoggerFactory.getLogger(LoginController.class);
	
	@Autowired
	SqlSession sqlSession;
	
	@RequestMapping(value="/login", method=RequestMethod.GET)
	public String loginForm() {
		logger.info("loginForm");
		return "main/login";
	}//loginForm
	
	@RequestMapping(value="/loginpro", method=RequestMethod.POST)
	public void loginPro(MemberVO vo, HttpSession session, PrintWriter out, HttpServletRequest req) {
		logger.info("loginPro");
		session = req.getSession();
		vo = sqlSession.selectOne("LoginMapper.loginPro", vo);
		int cnt = 0;
		if(vo != null && vo.getMember_id() != null && !vo.getMember_id().equals("")) {
			cnt = 1;
			session.setAttribute("memberVO", vo);
		}
		out.print(cnt);
		out.close();
	}//loginPro
	
	@RequestMapping(value="/logout", method=RequestMethod.GET)
	public String logout(HttpSession session) {
		logger.info("logout");
		session.invalidate();
		return "redirect:/home";
	}//logout
	
	@RequestMapping(value = "/exam_login", method = RequestMethod.GET)
	public String exam_login() {
		logger.info("examinee_login");
		return "exam/exam_login";
	}//exam_login폼
	
	@RequestMapping(value="/exam_loginpro", method=RequestMethod.POST)
	public void exam_loginpro(ExamineeVO vo, HttpSession session, PrintWriter out, HttpServletRequest req) {
		logger.info("exam_login");
		session = req.getSession();
		vo = sqlSession.selectOne("LoginMapper.ExamLogin", vo);
		int cnt = 0;
		if(vo != null && vo.getExaminee_id() != null && !vo.getExaminee_id().equals("")) {
			cnt = 1;
			session.setAttribute("ExamineeVO", vo);
		}
		out.print(cnt);
		out.close();
	}//exam_loginpro
	
}
