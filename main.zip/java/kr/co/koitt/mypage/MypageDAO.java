package kr.co.koitt.mypage;

import java.util.List;

import org.apache.ibatis.session.SqlSession;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

@Repository 
public class MypageDAO {

	@Autowired
	SqlSession sqlSession;

	public int apply_teacher(MypageVO vo) {
		int count = 0;
		count = sqlSession.insert("MypageMapper.ApplyTeacher", vo);
		return count;
	}//apply_teacher

	public List<MypageVO> TeacherApplyList() {
		List<MypageVO> list = null;
		list = sqlSession.selectList("MypageMapper.TeacherApplyList");
		return list;
	}//TeacherApplyList

	
}
