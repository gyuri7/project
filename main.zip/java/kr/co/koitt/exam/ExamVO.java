package kr.co.koitt.exam;

public class ExamVO {
	private String test_question_no;
	private String test_no;
	private String question_no;
	private String subject_no;
	private String question;
	private String question_answer;
	private String question_explain;
	
	public String getTest_question_no() {
		return test_question_no;
	}
	public void setTest_question_no(String test_question_no) {
		this.test_question_no = test_question_no;
	}
	public String getTest_no() {
		return test_no;
	}
	public void setTest_no(String test_no) {
		this.test_no = test_no;
	}
	public String getQuestion_no() {
		return question_no;
	}
	public void setQuestion_no(String question_no) {
		this.question_no = question_no;
	}
	public String getSubject_no() {
		return subject_no;
	}
	public void setSubject_no(String subject_no) {
		this.subject_no = subject_no;
	}
	public String getQuestion() {
		return question;
	}
	public void setQuestion(String question) {
		this.question = question;
	}
	public String getQuestion_answer() {
		return question_answer;
	}
	public void setQuestion_answer(String question_answer) {
		this.question_answer = question_answer;
	}
	public String getQuestion_explain() {
		return question_explain;
	}
	public void setQuestion_explain(String question_explain) {
		this.question_explain = question_explain;
	}
	
	
}
