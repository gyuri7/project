package kr.co.koitt.subject;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import kr.co.koitt.company.CompanyVO;
import kr.co.koitt.question.QuestionVO;
import kr.co.koitt.teacher.TeacherVO;

@Service
public class SubjectService {
	@Autowired
	SubjectDAO dao;
	
	public List<SubjectVO> selectSubject() {
		List<SubjectVO> listSubject = null;
		listSubject = dao.selectSubject();
		return listSubject ;
	}

	public List<QuestionVO> QuestionList() {
		List<QuestionVO> list =null;
		list = dao.QuestionList();
		return list;
	}

	public int insert(QuestionVO vo) {
		int successCnt = 0;
		successCnt = dao.insert(vo);
		return successCnt;
	}

	public int update(QuestionVO vo) {
		int successCnt = 0;
		successCnt = dao.update(vo);
		return successCnt;
	}

	public List<TeacherVO> lectureList() {
		List<TeacherVO> lectureList = null;
		lectureList = dao.lectureList();
		return lectureList;
	}//lectureList

	public List<CompanyVO> CompanyList() {
		List<CompanyVO> CompanyList = null;
		CompanyList = dao.CompanyList();
		return CompanyList;
	}

	public int update(CompanyVO vo) {
		int successCnt = 0;
		successCnt = dao.update(vo);
		return successCnt;
	}//question_update

	public int lecture_update(TeacherVO vo) {
		int cnt = 0;
		cnt = dao.lecture_update(vo);
		return cnt;
	}//lecture_update

}
