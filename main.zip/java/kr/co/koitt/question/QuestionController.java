package kr.co.koitt.question;

import java.io.IOException;
import java.io.PrintWriter;
import java.util.List;

import javax.servlet.http.HttpSession;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;

import kr.co.koitt.subject.SubjectService;
import kr.co.koitt.subject.SubjectVO;

@Controller
public class QuestionController {
	
	@Autowired
	QuestionService questionservice;
	
	@Autowired
    SubjectService subjectService;

private static final Logger logger = LoggerFactory.getLogger(QuestionController.class);
	
	@RequestMapping(value = "/teacher/question/write", method = RequestMethod.GET)
	public String formQuestionWrite(Model model) {//calling question insert form
		logger.info("=== formQuestionWrite ===");
		List<SubjectVO> listSubject = null;
		listSubject = subjectService.selectSubject();
		model.addAttribute("listSubject", listSubject);
		
		return "teacher/question/write"; 
	}//formQuestionWrite, 과목대분류
	
	
	@RequestMapping(value = "/teacher/question/insert", method = RequestMethod.POST)
	public void questionInsert(HttpSession session,PrintWriter out, QuestionVO vo) throws IOException {//question insert
		logger.info("=== questionInsert ===");
		int successCnt = 0;

		if(vo.getQuestion().indexOf(',') == 0) {
			vo.setQuestion(vo.getQuestion().substring(1));
		}				
		if(vo.getQuestion_explain().indexOf(',') == 0) {
			vo.setQuestion_explain(vo.getQuestion_explain().substring(1));
		}
		logger.info(vo.getSubject_no());
		logger.info(vo.getQuestion());
		logger.info(vo.getQuestion_answer());
		logger.info(vo.getQuestion_explain());
		successCnt = subjectService.insert(vo);
		out.print(successCnt);
		out.flush();
		out.close();
	}//questionInsert
	
	@RequestMapping(value = "/teacher/question/list", method = RequestMethod.GET)
	public String list(Model model, QuestionVO vo) {
		logger.info("=== list ===");
		List<QuestionVO> list =null;
		list = subjectService.QuestionList();
		model.addAttribute("QuestionList",list);
		
		return "teacher/question/list"; 
	}//list
	
	@RequestMapping(value = "/teacher/question/detail", method = RequestMethod.GET)
	public String detail(Model model, QuestionVO vo, PrintWriter out) {
		logger.info("=== detail ===");
		vo = questionservice.detail(vo);
		model.addAttribute("detailVO", vo);
		System.out.println(vo);
		
		return "teacher/question/detail"; 
	}//list
	
	
	@RequestMapping(value="/teacher/question/delete", method=RequestMethod.POST)
	public void delete(QuestionVO vo, PrintWriter out) {
		logger.info("=== delete ===");
		int successCnt = 0;
		successCnt = questionservice.delete(vo);
		out.println(successCnt);
		out.flush();
		out.close();
	}//delete
	
	@RequestMapping(value="/teacher/question/modify", method=RequestMethod.GET)
	public String modify(Model model, QuestionVO vo) {
		logger.info("=== modify ===");
		vo = questionservice.detail(vo);
		model.addAttribute("detailVO", vo);
		return "/teacher/question/modify";
	}//modify
	
	@RequestMapping(value = "/teacher/question/update", method = RequestMethod.POST)
	public void update(HttpSession session,PrintWriter out, QuestionVO vo) throws IOException {//question insert
		logger.info("=== update ===");
		int successCnt = 0;

		vo.setQuestion(vo.getQuestion().substring(vo.getQuestion().indexOf(",")+1));
		vo.setQuestion_answer(vo.getQuestion_answer().substring(vo.getQuestion_answer().indexOf(",")+1));
		vo.setQuestion_explain(vo.getQuestion_explain().substring(vo.getQuestion_explain().indexOf(",")+1));
//		if(vo.getQuestion_explain().indexOf(',') == 0) {
//			vo.setQuestion_explain(vo.getQuestion_explain().substring(1));
//		}
		logger.info(vo.getSubject_no());
		logger.info(vo.getQuestion());
		logger.info(vo.getQuestion_answer());
		logger.info(vo.getQuestion_explain());
		successCnt = subjectService.update(vo);
		out.print(successCnt);
		out.flush();
		out.close();
	}//questionInsert

}
