package kr.co.koitt.teacher;

import java.io.PrintWriter;
import java.util.List;

import javax.servlet.http.HttpSession;

import org.apache.ibatis.session.SqlSession;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;

import kr.co.koitt.subject.SubjectService;
import kr.co.koitt.subject.SubjectVO;
import kr.co.koitt.util.UtilForSession;

@Controller
public class TeacherController {
	
	@Autowired
    SubjectService subjectService;
	
	@Autowired
	TeacherService teacherService;
	
	private static final Logger logger = LoggerFactory.getLogger(TeacherController.class);
	
	@RequestMapping(value = "/lecture_insert", method = RequestMethod.GET)
	public String insertForm(Model model, HttpSession session) {
		List<SubjectVO> listSubject = null;
		listSubject = subjectService.selectSubject();
		model.addAttribute("listSubject", listSubject);
//		if(UtilForSession.chkSessionLevel(session, 2) == false) {
//			return "redirect:/main/home";
//		}
		return "teacher/lecture/lecture_insert";
	}//insertForm
	
	@RequestMapping(value = "/teacher/lecture/insert", method = RequestMethod.POST)
	public void teacher_lecture_insert(TeacherVO vo, PrintWriter out) {
		logger.info("teacher_lecture_insert");
		int count = 0;
		count = teacherService.teacher_lecture_insert(vo);
		out.print(count);
		out.flush();
		out.close();
	}//teacher_lecture_insert
	
	@RequestMapping(value = "/lecture_list", method = RequestMethod.GET)
	public String list(Model model, TeacherVO vo) {
		logger.info("list");
		List<TeacherVO> lectureList = null;
		lectureList = subjectService.lectureList();
		model.addAttribute("LectureList", lectureList);
		return "teacher/lecture/lecture_list";
	}//list
	
	@RequestMapping(value = "/lecture_detail", method = RequestMethod.GET)
	public String detail(Model model, TeacherVO vo, PrintWriter out) {
		logger.info("detail");
		vo = teacherService.lecture_detail(vo);
		model.addAttribute("detailVO", vo);
		return "teacher/lecture/lecture_detail";
	}//detail
	
	@RequestMapping(value = "/lecture_modify", method = RequestMethod.GET)
	public String modifyForm(Model model, TeacherVO vo) {
		logger.info("modifyForm");
		vo = teacherService.lecture_detail(vo);
		model.addAttribute("detailVO", vo);
		return "teacher/lecture/lecture_modify";
	}//modifyForm
	
	@RequestMapping(value = "/lecture_update", method = RequestMethod.POST)
	public void update(TeacherVO vo, PrintWriter out) {
		logger.info("update");
		int cnt = 0;
		cnt = subjectService.lecture_update(vo);
		out.print(cnt);
		out.flush();
		out.close();
	}//update
	
	@RequestMapping(value = "/lecture_delete", method = RequestMethod.POST)
	public void delete(TeacherVO vo, PrintWriter out) {
		logger.info("delete");
		int cnt = 0;
		cnt = teacherService.lecture_delete(vo);
		out.print(cnt);
		out.flush();
		out.close();
	}//delete
}







