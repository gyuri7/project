package kr.co.koitt.login;

import java.io.PrintWriter;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;

import org.apache.ibatis.session.SqlSession;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;

import kr.co.koitt.join.MemberVO;

@Controller
public class LoginController {
	
	private static final Logger logger = LoggerFactory.getLogger(LoginController.class);
	
	@Autowired
	SqlSession sqlSession;
	
	@RequestMapping(value="/main/login", method=RequestMethod.GET)
	public String loginForm() {
		logger.info("loginForm");
		return "main/login";
	}//login
	
	@RequestMapping(value="/loginpro", method=RequestMethod.POST)
	public void loginPro(MemberVO vo, HttpSession session, PrintWriter out, HttpServletRequest req) {
		logger.info("loginPro");
		session = req.getSession();
		vo = sqlSession.selectOne("LoginMapper.loginPro", vo);
		int cnt = 0;
		if(vo != null && vo.getMember_id() != null && !vo.getMember_id().equals("")) {
			cnt = 1;
			session.setAttribute("memberVO", vo);
		}
		out.print(cnt);
		out.close();
	}//loginPro
	
	@RequestMapping(value="/logout", method=RequestMethod.GET)
	public String logout(HttpSession session) {
		logger.info("logout");
		session.invalidate();
		return "redirect:/main/home";
	}//logout
	
	
}
