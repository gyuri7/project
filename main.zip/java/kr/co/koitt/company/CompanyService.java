package kr.co.koitt.company;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

@Service
public class CompanyService {
	
	@Autowired
	CompanyDAO dao;
	
	public int insert(CompanyVO vo) {
		int successCnt = 0;
		successCnt = dao.insert(vo);
		return successCnt;
	}//insert

	public CompanyVO detail(CompanyVO vo) {
		vo = dao.detail(vo);
		return vo;
	}//detail

	public int delete(CompanyVO vo) {
		int successCnt = 0;
		successCnt = dao.delete(vo);
		return successCnt;
	}//delete
	
	public int update(CompanyVO vo) {
		int successCnt = 0;
		successCnt = dao.update(vo);
		return successCnt;
	}//delete
	
}
