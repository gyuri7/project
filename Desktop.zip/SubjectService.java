package kr.co.koitt.subject;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

@Service
public class SubjectService {
	@Autowired
	SubjectDAO dao;
	
	public List<SubjectVO> selectSubject() {
		List<SubjectVO> listSubject = null;
		listSubject = dao.selectSubject();
		return listSubject ;
	}

}
