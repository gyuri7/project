package kr.co.koitt.company;

public class CompanyVO {
	
	private String test_no;
	private String member_no;	
	private String subject_no;
	private String subject_name;
	private String question_count;
	private String question_examinee_count;
	private String test_date;
	private String test_time;
	private String test_request_etc;
	
	
	public String getTest_no() {
		return test_no;
	}
	public void setTest_no(String test_no) {
		this.test_no = test_no;
	}
	public String getTest_date() {
		return test_date;
	}
	public void setTest_date(String test_date) {
		this.test_date = test_date;
	}
	public String getTest_time() {
		return test_time;
	}
	public void setTest_time(String test_time) {
		this.test_time = test_time;
	}
	public String getMember_no() {
		return member_no;
	}
	public void setMember_no(String member_no) {
		this.member_no = member_no;
	}
	public String getSubject_no() {
		return subject_no;
	}
	public void setSubject_no(String subject_no) {
		this.subject_no = subject_no;
	}
	
	public String getSubject_name() {
		return subject_name;
	}
	public void setSubject_name(String subject_name) {
		this.subject_name = subject_name;
	}
	public String getQuestion_count() {
		return question_count;
	}
	public void setQuestion_count(String question_count) {
		this.question_count = question_count;
	}
	public String getQuestion_examinee_count() {
		return question_examinee_count;
	}
	public void setQuestion_examinee_count(String question_examinee_count) {
		this.question_examinee_count = question_examinee_count;
	}
	public String getTest_request_etc() {
		return test_request_etc;
	}
	public void setTest_request_etc(String test_request_etc) {
		this.test_request_etc = test_request_etc;
	}
	
	
}
