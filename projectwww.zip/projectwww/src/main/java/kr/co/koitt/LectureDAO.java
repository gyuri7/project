package kr.co.koitt;

import java.util.List;

import org.apache.ibatis.session.SqlSession;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import kr.co.koitt.teacher.TeacherVO;

@Repository
public class LectureDAO {
	
	@Autowired
	SqlSession sqlSession;

	public List<TeacherVO> selectLecture() {
		List<TeacherVO> mainLectureList = null;
		mainLectureList = sqlSession.selectList("LectureMapper.SelectLecture");
		return mainLectureList;
	}//selectLecture

}
