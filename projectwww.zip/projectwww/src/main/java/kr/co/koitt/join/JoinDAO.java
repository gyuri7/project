package kr.co.koitt.join;

import org.apache.ibatis.session.SqlSession;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

@Repository
public class JoinDAO {
	
	@Autowired
	SqlSession sqlSession;
	
	public int join_insert(MemberVO vo) {
		int cnt = 0;
		cnt = sqlSession.insert("JoinMapper.JoinInsert",vo);
		return cnt;
	}//join_insert

	public int idCheck(MemberVO vo) {
		int cnt = 0;
		cnt = sqlSession.selectOne("JoinMapper.IdCheck", vo);
		return cnt;
	}//idCheck

}
