package kr.co.koitt.mypage;

import org.springframework.web.multipart.MultipartFile;

public class MypageVO {

	private String writer;
	private MultipartFile teacher_image;
	private MultipartFile img;
	private String education;
	private String d_career;
	private String l_career;
	private String bank;
	private String account_no;
	private String account_holder;
	
	
	public String getWriter() {
		return writer;
	}
	public void setWriter(String writer) {
		this.writer = writer;
	}
	public MultipartFile getTeacher_image() {
		return teacher_image;
	}
	public void setTeacher_image(MultipartFile teacher_image) {
		this.teacher_image = teacher_image;
	}
	public MultipartFile getImg() {
		return img;
	}
	public void setImg(MultipartFile img) {
		this.img = img;
	}
	public String getEducation() {
		return education;
	}
	public void setEducation(String education) {
		this.education = education;
	}
	public String getD_career() {
		return d_career;
	}
	public void setD_career(String d_career) {
		this.d_career = d_career;
	}
	public String getL_career() {
		return l_career;
	}
	public void setL_career(String l_career) {
		this.l_career = l_career;
	}
	public String getBank() {
		return bank;
	}
	public void setBank(String bank) {
		this.bank = bank;
	}
	public String getAccount_no() {
		return account_no;
	}
	public void setAccount_no(String account_no) {
		this.account_no = account_no;
	}
	public String getAccount_holder() {
		return account_holder;
	}
	public void setAccount_holder(String account_holder) {
		this.account_holder = account_holder;
	}
	
	
	
}
