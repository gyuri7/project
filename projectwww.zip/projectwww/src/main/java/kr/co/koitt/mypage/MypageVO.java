package kr.co.koitt.mypage;

import org.springframework.web.multipart.MultipartFile;

public class MypageVO {

	private String member_no;
	private String teacher_devel_career;
	private String teacher_lecture_career;
	private String teacher_bank;
	private String teacher_account_no;
	private String account_holder;
	private String teacher_apply_date;
	
	public String getMember_no() {
		return member_no;
	}
	public void setMember_no(String member_no) {
		this.member_no = member_no;
	}
	public String getTeacher_devel_career() {
		return teacher_devel_career;
	}
	public void setTeacher_devel_career(String teacher_devel_career) {
		this.teacher_devel_career = teacher_devel_career;
	}
	public String getTeacher_lecture_career() {
		return teacher_lecture_career;
	}
	public void setTeacher_lecture_career(String teacher_lecture_career) {
		this.teacher_lecture_career = teacher_lecture_career;
	}
	public String getTeacher_bank() {
		return teacher_bank;
	}
	public void setTeacher_bank(String teacher_bank) {
		this.teacher_bank = teacher_bank;
	}
	public String getTeacher_account_no() {
		return teacher_account_no;
	}
	public void setTeacher_account_no(String teacher_account_no) {
		this.teacher_account_no = teacher_account_no;
	}
	public String getAccount_holder() {
		return account_holder;
	}
	public void setAccount_holder(String account_holder) {
		this.account_holder = account_holder;
	}
	public String getTeacher_apply_date() {
		return teacher_apply_date;
	}
	public void setTeacher_apply_date(String teacher_apply_date) {
		this.teacher_apply_date = teacher_apply_date;
	}
	
	
	
}
