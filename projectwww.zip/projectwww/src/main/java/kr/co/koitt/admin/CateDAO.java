package kr.co.koitt.admin;

import org.apache.ibatis.session.SqlSession;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import kr.co.koitt.subject.SubjectVO;

@Repository
public class CateDAO {

	@Autowired
	SqlSession sqlSession;
	public int cate_insert(SubjectVO vo) {
		int count = 0;
		count = sqlSession.insert("AdminMapper.CateInsert", vo);
		return count;
	}//insert
	
	public int cate_delete(SubjectVO vo) {
		int count = 0;
		count = sqlSession.delete("AdminMapper.CateDelete", vo);
		return count;
	}//delete

}
