package kr.co.koitt.teacher;

public class TeacherVO {
	private String lecture_no;
	private String member_no;
	private String subject_no;
	private String lecture_name;
	private String lecture_difficulty;
	private String lecture_period;
	private String lecture_introduction;
	private String lecture_date;
	
	public String getLecture_no() {
		return lecture_no;
	}
	public void setLecture_no(String lecture_no) {
		this.lecture_no = lecture_no;
	}
	public String getMember_no() {
		return member_no;
	}
	public void setMember_no(String member_no) {
		this.member_no = member_no;
	}
	public String getSubject_no() {
		return subject_no;
	}
	public void setSubject_no(String subject_no) {
		this.subject_no = subject_no;
	}
	public String getLecture_name() {
		return lecture_name;
	}
	public void setLecture_name(String lecture_name) {
		this.lecture_name = lecture_name;
	}
	public String getLecture_difficulty() {
		return lecture_difficulty;
	}
	public void setLecture_difficulty(String lecture_difficulty) {
		this.lecture_difficulty = lecture_difficulty;
	}
	public String getLecture_period() {
		return lecture_period;
	}
	public void setLecture_period(String lecture_period) {
		this.lecture_period = lecture_period;
	}
	public String getLecture_introduction() {
		return lecture_introduction;
	}
	public void setLecture_introduction(String lecture_introduction) {
		this.lecture_introduction = lecture_introduction;
	}
	public String getLecture_date() {
		return lecture_date;
	}
	public void setLecture_date(String lecture_date) {
		this.lecture_date = lecture_date;
	}
	
}
