package kr.co.koitt.board;

public class BoardVO {
	
	private String board_no;
	private String member_no;
	private String board_level;
	private String board_title;
	private String board_contents;
	private String board_date;
	private String board_hit;
	private String board_attachment;
	
	public String getBoard_no() {
		return board_no;
	}
	public void setBoard_no(String board_no) {
		this.board_no = board_no;
	}
	public String getMember_no() {
		return member_no;
	}
	public void setMember_no(String member_no) {
		this.member_no = member_no;
	}
	public String getBoard_level() {
		return board_level;
	}
	public void setBoard_level(String board_level) {
		this.board_level = board_level;
	}
	public String getBoard_title() {
		return board_title;
	}
	public void setBoard_title(String board_title) {
		this.board_title = board_title;
	}
	public String getBoard_contents() {
		return board_contents;
	}
	public void setBoard_contents(String board_contents) {
		this.board_contents = board_contents;
	}
	public String getBoard_date() {
		return board_date;
	}
	public void setBoard_date(String board_date) {
		this.board_date = board_date;
	}
	public String getBoard_hit() {
		return board_hit;
	}
	public void setBoard_hit(String board_hit) {
		this.board_hit = board_hit;
	}
	public String getBoard_attachment() {
		return board_attachment;
	}
	public void setBoard_attachment(String board_attachment) {
		this.board_attachment = board_attachment;
	}
	
	
	
}//class
