package kr.co.koitt.mypage;

import org.apache.ibatis.session.SqlSession;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

@Repository 
public class MypageDAO {

	@Autowired
	SqlSession sqlSession;

	public int apply_teacher(MypageVO vo) {
		int count = 0;
		count = sqlSession.insert("MypageMapper.ApplyTeacher", vo);
		return count;
	}//apply_teacher

	
}
