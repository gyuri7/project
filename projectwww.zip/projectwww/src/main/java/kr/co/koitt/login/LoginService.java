package kr.co.koitt.login;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import kr.co.koitt.join.MemberVO;

@Service
public class LoginService {
	
	@Autowired
	LoginDAO dao;
	
	public int loginPro(MemberVO vo) {
		int cnt = 0;
		cnt = dao.loginPro(vo);
		return cnt;
	}//loginPro

}
