package kr.co.koitt.admin;

import java.io.PrintWriter;
import java.util.List;

import org.apache.ibatis.session.SqlSession;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;

import kr.co.koitt.question.QuestionVO;
import kr.co.koitt.subject.SubjectService;
import kr.co.koitt.subject.SubjectVO;


@Controller
public class CateController {
	
	@Autowired
	CateService cateservice;
	
	@Autowired
	SubjectService subjectService;
	
	private static final Logger logger = LoggerFactory.getLogger(CateController.class);
	

	@RequestMapping(value = "/admin/cate", method = RequestMethod.GET)
	public String form(Model model) {
		logger.info("/admin/cate");
		List<SubjectVO> list = subjectService.selectSubject();
		model.addAttribute("subject_list", list);
		return "admin/cate";
	}///main/admin/cate
	
	@RequestMapping(value = "/admin/cateins", method = RequestMethod.POST)
	public void insert(SubjectVO vo, PrintWriter out) {
		logger.info("insert");
		int count = 0;
		count = cateservice.cate_insert(vo);
		out.print(count);
		out.flush();
		out.close();
	}//insert

	@RequestMapping(value="/admin/catedel", method = RequestMethod.POST)
	public void delete(SubjectVO vo, PrintWriter out) {
		logger.info("=== delete ===");
		int count = 0;
		count = cateservice.cate_delete(vo);
		out.println(count);
		out.flush();
		out.close();
	}//delete
	
}

