package kr.co.koitt.question;

import java.util.List;

import org.apache.ibatis.session.SqlSession;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import kr.co.koitt.subject.SubjectVO;

@Repository
public class QuestionDAO {
	
	@Autowired
	SqlSession sqlSession;

	public List<QuestionVO> QuestionList() {
		List<QuestionVO> list = null;
		list = sqlSession.selectList("QuestionMapper.QuestionList");
		return list;
	}//QuestionList

	public int insert(QuestionVO vo) {
		int successCnt = 0;
		successCnt = sqlSession.insert("QuestionMapper.QuestionInsert", vo);
		return successCnt;
	}//insert

	public QuestionVO detail(QuestionVO vo) {
		vo = sqlSession.selectOne("QuestionMapper.QuestionDetail", vo);
		return vo;
	}//detail

	public int delete(QuestionVO vo) {
		int successCnt = 0;
		successCnt = sqlSession.delete("QuestionMapper.QuestionDelete",vo);
		return successCnt;
	}//delete

	public int update(QuestionVO vo) {
		int successCnt = 0;
		successCnt = sqlSession.update("QuestionMapper.QuestionUpdate",vo);
		return successCnt;
	}

	
	
}
