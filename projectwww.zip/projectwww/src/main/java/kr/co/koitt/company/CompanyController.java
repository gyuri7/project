package kr.co.koitt.company;

import java.io.IOException;
import java.io.PrintWriter;
import java.util.List;

import javax.servlet.http.HttpSession;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;

import kr.co.koitt.question.QuestionVO;
import kr.co.koitt.subject.SubjectService;
import kr.co.koitt.subject.SubjectVO;

@Controller
public class CompanyController {
	
	@Autowired
    SubjectService subjectService;
	
	@Autowired
	CompanyService companyService; 

private static final Logger logger = LoggerFactory.getLogger(CompanyController.class);
	
	@RequestMapping(value = "/company/test_write", method = RequestMethod.GET)
	public String formTestWrite(Model model) {//calling question insert form
		logger.info("=== formTestWrite ===");
		List<SubjectVO> listSubject = null;
		listSubject = subjectService.selectSubject();
		model.addAttribute("listSubject", listSubject);

		return "company/test_write"; 
	}//formTestWrite, 과목대분류

	@RequestMapping(value = "/company/test_insert", method = RequestMethod.POST)
	public void testInsert(HttpSession session,PrintWriter out, CompanyVO vo) throws IOException {//question insert
		logger.info("=== testInsert ===");
		int successCnt = 0;
		successCnt = companyService.insert(vo);
		out.print(successCnt);
		out.flush();
		out.close();
	}//testInsert
	
}	


