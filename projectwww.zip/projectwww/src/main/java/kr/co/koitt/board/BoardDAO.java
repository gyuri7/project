package kr.co.koitt.board;

import java.util.List;

import org.apache.ibatis.session.SqlSession;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

@Repository
public class BoardDAO {

	@Autowired
	SqlSession sqlSession;
	
	public int insert(BoardVO vo) {
		int count = 0;
		count = sqlSession.insert("AdminMapper.BoardInsert", vo);
		return count;
	}
	
	public List<BoardVO> List() {
		List<BoardVO> list = null;
		list = sqlSession.selectList("AdminMapper.BoardList");
		return list;
	}//BoradList


}//class
