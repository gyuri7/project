package kr.co.koitt.mypage;

import java.io.PrintWriter;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;


@Controller
public class MypageController {
	
	private static final Logger logger = LoggerFactory.getLogger(MypageController.class);
	
	@Autowired
	MypageService mypageService;
	
	
	@RequestMapping(value="/main/mypage/my_lecture_write", method=RequestMethod.GET)
	public String write(Model model) {
		logger.info("=== write ===");
		return "main/mypage/my_lecture_write";
	}//write
	
	@RequestMapping(value = "/apply_teacher", method = RequestMethod.GET)
	public void teacher(MypageVO vo, PrintWriter out) {
		logger.info("MypageInsert");
		int count = 0;
		count = mypageService.apply_teacher(vo);		
		out.print(count);
		out.flush();
		out.close();
	}//teacher
	
	
}
