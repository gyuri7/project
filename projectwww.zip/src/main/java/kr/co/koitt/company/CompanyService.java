package kr.co.koitt.company;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;



@Service
public class CompanyService {
	
	@Autowired
	CompanyDAO dao;
	
	public int insert(CompanyVO vo) {
		int successCnt = 0;
		successCnt = dao.insert(vo);
		return successCnt;
	}

	
}
