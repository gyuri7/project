package kr.co.koitt.company;

import org.apache.ibatis.session.SqlSession;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;


@Repository
public class CompanyDAO {
	
	@Autowired
	SqlSession sqlSession;
	
	public int insert(CompanyVO vo) {
		int successCnt = 0;
		successCnt = sqlSession.insert("CompanyMapper.companyInsert", vo);
		return successCnt;
	}//insert
}
