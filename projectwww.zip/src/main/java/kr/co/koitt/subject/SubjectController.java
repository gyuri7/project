package kr.co.koitt.subject;

import java.util.List;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;

import kr.co.koitt.question.QuestionController;



public class SubjectController {
	
	@Autowired
    SubjectService subjectService;
	
	private static final Logger logger = LoggerFactory.getLogger(QuestionController.class);
	
	@RequestMapping(value = "/teacher/question/write", method = RequestMethod.GET)
	public String formQuestionWrite(Model model) {
		logger.info("=== formQuestionWrite ===");
		List<SubjectVO> listSubject = null;
		listSubject = subjectService.selectSubject();
		model.addAttribute("listSubject", listSubject);
		return "teacher/question/write"; 
	}//formQuestionWrite
}
