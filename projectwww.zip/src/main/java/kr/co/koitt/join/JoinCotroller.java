package kr.co.koitt.join;

import java.io.PrintWriter;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;

import kr.co.koitt.question.QuestionController;

@Controller
public class JoinCotroller {
	
	@Autowired
	JoinService joinService;
	
	private static final Logger logger = LoggerFactory.getLogger(QuestionController.class);
	
	@RequestMapping(value="/main/join", method=RequestMethod.POST)
	public void join(MemberVO vo, PrintWriter out) {
		logger.info("join");
		int cnt = 0;
		cnt = joinService.join_insert(vo);
		out.print(cnt);
		out.flush();
		out.close();
	}//join

}
