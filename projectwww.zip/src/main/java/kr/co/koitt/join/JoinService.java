package kr.co.koitt.join;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

@Service
public class JoinService {
	
	@Autowired
	JoinDAO dao;

	public int join_insert(MemberVO vo) {
		int cnt = 0;
		cnt = dao.join_insert(vo);
		return cnt;
	}//join_insert

}
