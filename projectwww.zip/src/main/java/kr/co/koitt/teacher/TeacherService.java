package kr.co.koitt.teacher;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import kr.co.koitt.question.QuestionVO;

@Service
public class TeacherService {
	
	@Autowired
	TeacherDAO dao;

	public int teacher_lecture_insert(TeacherVO vo) {
		int count = 0;
		count = dao.teacher_lecture_insert(vo);
		return count;
	}//teacher_insert
	
	public List<TeacherVO> lectureList() {
		List<TeacherVO> lectureList = null;
		lectureList = dao.lectureList();
		return lectureList;
	}//lectureList


	

}
