package kr.co.koitt.teacher;

import java.util.List;

import org.apache.ibatis.session.SqlSession;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import kr.co.koitt.question.QuestionVO;

@Repository
public class TeacherDAO {
	
	@Autowired
	SqlSession sqlSession;

	public int teacher_lecture_insert(TeacherVO vo) {
		int count = 0;
//		System.out.println("TeacherDAO : "+vo.getMember_no());
//		System.out.println("TeacherDAO : "+vo.getLecture_book());
//		System.out.println("TeacherDAO : "+vo.getLecture_difficulty());
//		System.out.println("TeacherDAO : "+vo.getLecture_introduction());
//		System.out.println("TeacherDAO : "+vo.getLecture_name());
//		System.out.println("TeacherDAO : "+vo.getSubject_no());
		count = sqlSession.insert("TeacherMapper.LectureInsert",vo);
		return count;
	}//teacher_lecture_insert

	public List<TeacherVO> lectureList() {
		List<TeacherVO> lectureList = null;
		lectureList = sqlSession.selectList("TeacherMapper.LectureList");
		return lectureList;
	}//lectureList

}
