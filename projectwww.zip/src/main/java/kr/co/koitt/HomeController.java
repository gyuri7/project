package kr.co.koitt;

import java.text.DateFormat;
import java.util.Date;
import java.util.Locale;

import org.apache.ibatis.session.SqlSession;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;

@Controller
public class HomeController {
	
	@Autowired
	SqlSession sqlSession;
	
	private static final Logger logger = LoggerFactory.getLogger(HomeController.class);
	
	@RequestMapping(value = "/", method = RequestMethod.GET)
	public String home(Locale locale, Model model) {
		logger.info("Welcome home! The client locale is {}.", locale);
		
		Date date = new Date();
		DateFormat dateFormat = DateFormat.getDateTimeInstance(DateFormat.LONG, DateFormat.LONG, locale);
		
		String formattedDate = dateFormat.format(date);
		
		model.addAttribute("serverTime", formattedDate );
		
		return "home";
	}//home
	
	@RequestMapping(value = "/main/home", method = RequestMethod.GET)
	public String main() {
		logger.info("main");
		return "main/home";
	}
	
	@RequestMapping(value = "/main/login_home", method = RequestMethod.GET)
	public String home2() {
		logger.info("home2");
		return "main/login_home";
	}
	
	@RequestMapping(value = "/main/lecture/lecture_list", method = RequestMethod.GET)
	public String main_lecture() {
		logger.info("main_lecture");
		return "main/lecture/lecture_list";
	}
	
	@RequestMapping(value = "/examinee/login", method = RequestMethod.GET)
	public String examinee_login() {
		logger.info("examinee_login");
		return "examinee/login";
	}
	
	@RequestMapping(value = "/main/mypage/my_lecture", method = RequestMethod.GET)
	public String main_mypage() {
		logger.info("main_mypage");
		return "main/mypage/my_lecture";
	}
	
	@RequestMapping(value = "/main/mypage/my_payment", method = RequestMethod.GET)
	public String main_mypage_payment() {
		logger.info("main_mypage_payment");
		return "main/mypage/my_payment";
	}
	
}
