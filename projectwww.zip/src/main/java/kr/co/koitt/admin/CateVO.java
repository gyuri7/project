package kr.co.koitt.admin;

public class CateVO {

}
