package kr.co.koitt.admin;

import java.io.PrintWriter;

import org.apache.ibatis.session.SqlSession;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;


@Controller
public class CateController {
	
	@Autowired
	CateService cateservice;
	
	private static final Logger logger = LoggerFactory.getLogger(CateController.class);
	

	@RequestMapping(value = "/main/admin/cate", method = RequestMethod.GET)
	public String form() {
		logger.info("form");
		return "main/admin/cate";
	}//form
	
	@RequestMapping(value = "/main/admin/cate", method = RequestMethod.GET)
	public String insert(CateVO vo, PrintWriter out) {
		logger.info("insert");
		int count = 0;
		count = cateservice.cate_insert(vo);
		out.print(count);
		out.flush();
		out.close();
	}//insert
			
}

