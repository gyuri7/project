package kr.co.koitt.admin;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

@Service
public class CateService {

	@Autowired
	CateDAO dao;
	
	public int cate_insert(CateVO vo) {
		int count = 0;
		count = dao.cate_insert(vo);
		return count;
	}

}
