package kr.co.koitt.util;

import javax.servlet.http.HttpSession;

import kr.co.koitt.join.MemberVO;

public class UtilForSession {

	public static boolean chkSession(HttpSession session) {
		MemberVO sessionVO = (MemberVO) session.getAttribute("memberVO");
		boolean chkSessionResult = true;
		if(sessionVO == null || sessionVO.getMember_no().equals("")) {
			chkSessionResult = false;
		}
		return chkSessionResult;
	}//chkSession

	public static boolean chkSessionLevel(HttpSession session, int memberLevel) {
		MemberVO sessionVO = (MemberVO) session.getAttribute("memberVO");
		boolean chkSessionResult = true;
		if(sessionVO == null || sessionVO.getMember_no().equals("")) {
			chkSessionResult = false;
		} else if(Integer.parseInt(sessionVO.getMember_class()) != memberLevel) {
			chkSessionResult = false;
		}
		return chkSessionResult;
	}//chkSessionLevel

}//class
