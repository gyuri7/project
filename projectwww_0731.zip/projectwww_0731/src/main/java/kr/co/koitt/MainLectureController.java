package kr.co.koitt;

import java.util.List;

import javax.servlet.http.HttpSession;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;

import kr.co.koitt.join.MemberVO;
import kr.co.koitt.lecture.ChapterVO;
import kr.co.koitt.lecture.LectureService;
import kr.co.koitt.lecture.LectureVO;
import kr.co.koitt.util.SearchVO;
import kr.co.koitt.util.UtilForPaging;

@Controller
public class MainLectureController {
	
	@Autowired
	MainLectureService mainLectureService;
	
	@Autowired
	LectureService lectureService;
	
	private static final Logger logger = LoggerFactory.getLogger(MainLectureController.class);
	
	@RequestMapping(value = "/main_lecture", method = RequestMethod.GET)
	public String main_lecture_list(Model model, SearchVO searchVO) {
		logger.info("main_lecture_list");
		UtilForPaging.setListRange(searchVO);
		List<LectureVO> mainLectureList = null;
		mainLectureList = mainLectureService.lectureList(searchVO);
		model.addAttribute("MainLectureList", mainLectureList);
		//paging start =====
		int totalCount = 0;
		totalCount = mainLectureService.listCnt(searchVO);
		UtilForPaging.setPagingToVO(searchVO, totalCount);
		model.addAttribute("searchVO", searchVO);
		//paging end =====
		return "main/lecture/lecture_list";
	}//main_lecture_list
	
	@RequestMapping(value = "/main_lecture_detail", method = RequestMethod.GET)
	public String main_lecture_detail(HttpSession session, Model model, LectureVO vo) {
		logger.info("main_lecture_detail");
		if(session.getAttribute("memberVO") != null) {
			MemberVO mvo = (MemberVO) session.getAttribute("memberVO");
			vo.setMember_no(mvo.getMember_no());
		}
		vo = lectureService.lecture_detail(vo);
		model.addAttribute("detailVO", vo);
		//chapter list
		List<ChapterVO> chapterList = null;
		chapterList = lectureService.chapterList(vo);
		model.addAttribute("ChapterList", chapterList);
		return "main/lecture/lecture_detail";
	}//main_lecture_detail
	
}
