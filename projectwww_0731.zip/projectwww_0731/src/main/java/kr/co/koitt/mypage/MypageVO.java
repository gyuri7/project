package kr.co.koitt.mypage;

import org.springframework.web.multipart.MultipartFile;

public class MypageVO {

	private String member_no;
	private String teacher_name;
	private String teacher_devel_career;
	private String teacher_lecture_career;
	private String teacher_apply_date;
	private String teacher_image_name;
	private MultipartFile image_file;
	private String teacher_education_name;
	private MultipartFile education_file;
	
	public String getMember_no() {
		return member_no;
	}
	public void setMember_no(String member_no) {
		this.member_no = member_no;
	}
	public String getTeacher_name() {
		return teacher_name;
	}
	public void setTeacher_name(String teacher_name) {
		this.teacher_name = teacher_name;
	}
	public String getTeacher_devel_career() {
		return teacher_devel_career;
	}
	public void setTeacher_devel_career(String teacher_devel_career) {
		this.teacher_devel_career = teacher_devel_career;
	}
	public String getTeacher_lecture_career() {
		return teacher_lecture_career;
	}
	public void setTeacher_lecture_career(String teacher_lecture_career) {
		this.teacher_lecture_career = teacher_lecture_career;
	}
	public String getTeacher_apply_date() {
		return teacher_apply_date;
	}
	public void setTeacher_apply_date(String teacher_apply_date) {
		this.teacher_apply_date = teacher_apply_date;
	}
	public String getTeacher_image_name() {
		return teacher_image_name;
	}
	public void setTeacher_image_name(String teacher_image_name) {
		this.teacher_image_name = teacher_image_name;
	}
	public MultipartFile getImage_file() {
		return image_file;
	}
	public void setImage_file(MultipartFile image_file) {
		this.image_file = image_file;
	}
	public String getTeacher_education_name() {
		return teacher_education_name;
	}
	public void setTeacher_education_name(String teacher_education_name) {
		this.teacher_education_name = teacher_education_name;
	}
	public MultipartFile getEducation_file() {
		return education_file;
	}
	public void setEducation_file(MultipartFile education_file) {
		this.education_file = education_file;
	}
	
	
	
}
