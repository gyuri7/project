package kr.co.koitt.join;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

@Service
public class JoinService {
	
	@Autowired
	JoinDAO dao;

	public int join_insert(MemberVO vo) {
		int cnt = 0;
		cnt = dao.join_insert(vo);
		if (vo.getMember_level().equals("3") && cnt > 0) {
			cnt = dao.company_join(vo);
		}
		return cnt;
	}//join_insert

	public int idCheck(MemberVO vo) {
		int cnt = 0;
		cnt = dao.idCheck(vo);
		return cnt;
	}//idCheck

}
