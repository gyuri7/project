package kr.co.koitt.lecture;

import java.util.ArrayList;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import kr.co.koitt.join.MemberVO;

@Service
public class LectureService {
	
	@Autowired
	LectureDAO dao;

	public int teacher_lecture_insert(LectureVO vo) {
		int count = 0;
		count = dao.teacher_lecture_insert(vo);
		return count;
	}//teacher_lecture_insert
	
	public int file_path_update(LectureVO vo) {
		int count = 0;
		count = dao.file_path_update(vo);
		return count;
	}//file_path_update
	
	public List<LectureVO> lectureList(MemberVO mvo) {
		List<LectureVO> lectureList = null;
		lectureList = dao.lectureList(mvo);
		return lectureList;
	}//lectureList
	
	public LectureVO lecture_detail(LectureVO vo) {
		vo = dao.lecture_detail(vo);
		return vo;
	}//lecture_detail

	public int lecture_update(LectureVO vo) {
		int cnt = 0;
		cnt = dao.lecture_update(vo);
		return cnt;
	}//lecture_update

	public int lecture_delete(LectureVO vo) {
		int cnt = 0;
		cnt = dao.lecture_delete(vo);
		return cnt;
	}//lecture_delete
	
	/////////////////////////////////chapter/////////////////////////////////
	public LectureVO selectDetail(LectureVO vo) {
		vo = dao.selectDetail(vo);
		return vo;
	}//selectDetail 챕터화면에서 강의정보 불러오기
	
	public int chapter_insert(ArrayList<ChapterVO> chapterList) {
		int count = 0;
		count = dao.chapter_insert(chapterList);
		return count;
	}//chapter_insert
	
	public List<ChapterVO> chapterList(LectureVO vo) {
		List<ChapterVO> chapterList = null;
		chapterList = dao.chapterList(vo);
		return chapterList;
	}//chapterList

	public ChapterVO chapter_modify(ChapterVO vo) {
		vo = dao.chapter_modify(vo);
		return vo;
	}//chapter_modify

	public int chapter_update(ChapterVO vo) {
		int cnt = 0;
		cnt = dao.chapter_update(vo);
		return cnt;
	}//chapter_update

	public int chapter_delete(ChapterVO vo) {
		int cnt = 0;
		cnt = dao.chapter_delete(vo);
		return cnt;
	}//chapter_delete

}
