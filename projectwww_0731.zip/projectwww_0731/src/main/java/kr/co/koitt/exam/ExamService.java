package kr.co.koitt.exam;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import kr.co.koitt.join.ExamineeVO;
import kr.co.koitt.question.ExampleVO;
import kr.co.koitt.question.QuestionVO;

@Service
public class ExamService {
	
	@Autowired
	ExamDAO dao;
	
	public List<ExamVO> selectExam() {
		List<ExamVO> examList = null;
		examList = dao.selectExam();
		return examList ;
	}

	public List<ExampleVO> exampleList(List<QuestionVO> questionList) {
		List<ExampleVO> exampleList = null;
		exampleList = dao.exampleList(questionList);
		return exampleList;
	}

	public List<QuestionVO> selectQuestion(ExamineeVO examVO) {
		List<QuestionVO> questionList = null;
		questionList = dao.selectQuestion(examVO);
		return questionList ;
	}
}
