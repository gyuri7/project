package kr.co.koitt.util;

public class SearchVO extends PagingVO {

	private String btype;
	private String search_word;

	public String getBtype() {
		return btype;
	}
	public void setBtype(String btype) {
		this.btype = btype;
	}
	public String getSearch_word() {
		return search_word;
	}
	public void setSearch_word(String search_word) {
		this.search_word = search_word;
	}

}//class
