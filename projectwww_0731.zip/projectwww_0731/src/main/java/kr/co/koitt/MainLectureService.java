package kr.co.koitt;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import kr.co.koitt.lecture.LectureVO;
import kr.co.koitt.util.SearchVO;

@Service
public class MainLectureService {
	
	@Autowired
	MainLectureDAO dao;

	public List<LectureVO> lectureList(SearchVO searchVO) {
		List<LectureVO> mainLectureList = null;
		mainLectureList = dao.lectureList(searchVO);
		return mainLectureList;
	}//lectureList
	
	public int listCnt(SearchVO searchVO) {
		int totalCount = 0;
		totalCount = dao.listCnt(searchVO);
		return totalCount;
	}//listCnt

}
