package kr.co.koitt.board;

import java.util.List;

import org.apache.ibatis.session.SqlSession;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

@Repository
public class BoardDAO {

	@Autowired
	SqlSession sqlSession;
	
	public int insert(BoardVO vo) {
		int count = 0;
		count = sqlSession.insert("BoardMapper.BoardInsert", vo);
		return count;
	}//BoardInsert
	
	public List<BoardVO> List() {
		List<BoardVO> list = null;
		list = sqlSession.selectList("BoardMapper.BoardList");
		return list;
	}//BoradList

	public BoardVO detail(BoardVO vo) {
		vo = sqlSession.selectOne("BoardMapper.BoardDetail", vo);
		return vo;
	}//BoardDetail

	public int delete(BoardVO vo) {
		int count = 0;
		count = sqlSession.delete("BoardMapper.BoardDelete", vo);
		return count;
	}//BoardDelete


}//class
