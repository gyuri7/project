package kr.co.koitt.util;

public class UtilForPaging {

	public static void setListRange(PagingVO vo) {
		int listEndNo = 5;
		int listStartNo = 5 - 4;
		if(vo == null || vo.getPage() == null || vo.getPage().equals("")) {
			vo.setPage("1");
		} else {
			listEndNo = Integer.parseInt(vo.getPage()) * 5;
			listStartNo = listEndNo - 4;
		}
		vo.setListStartNo(""+listStartNo);
		vo.setListEndNo(""+listEndNo);
	}//setListRange

	public static void setPagingToVO(PagingVO vo, int totalCount) {
		int startPage = 1;
		int endPage = 1;
		int totPage = 1;
		if(totalCount > 0) {
			totPage = totalCount / 5;
			if((totalCount % 5) > 0) {
				totPage++;
			}
		}//if
		if(vo.getPage().length() > 1) {
			String tmp = vo.getPage().substring(0, vo.getPage().length()-1);
			tmp = tmp + "1";
			startPage = Integer.parseInt(tmp);
			if(vo.getPage().endsWith("0")) {
				startPage = startPage - 5;
			}
		}//if
		if((startPage + 4) < totPage) {
			endPage = startPage + 4;
		} else {
			endPage = totPage;
		}
		vo.setEndPage(""+endPage);
		vo.setStartPage(""+startPage);
		vo.setTotPage(""+totPage);
	}//setPagingToVO

}//class
