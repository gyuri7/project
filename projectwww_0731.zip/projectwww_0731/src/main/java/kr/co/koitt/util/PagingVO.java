package kr.co.koitt.util;

public class PagingVO {

	private String page;
	private String listStartNo;
	private String listEndNo;
	private String startPage;
	private String endPage;
	private String totPage;

	public String getPage() {
		return page;
	}
	public void setPage(String page) {
		this.page = page;
	}
	public String getListStartNo() {
		return listStartNo;
	}
	public void setListStartNo(String listStartNo) {
		this.listStartNo = listStartNo;
	}
	public String getListEndNo() {
		return listEndNo;
	}
	public void setListEndNo(String listEndNo) {
		this.listEndNo = listEndNo;
	}
	public String getStartPage() {
		return startPage;
	}
	public void setStartPage(String startPage) {
		this.startPage = startPage;
	}
	public String getEndPage() {
		return endPage;
	}
	public void setEndPage(String endPage) {
		this.endPage = endPage;
	}
	public String getTotPage() {
		return totPage;
	}
	public void setTotPage(String totPage) {
		this.totPage = totPage;
	}

}//class
