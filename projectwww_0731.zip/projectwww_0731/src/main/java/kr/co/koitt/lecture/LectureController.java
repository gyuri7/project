package kr.co.koitt.lecture;

import java.io.PrintWriter;
import java.util.ArrayList;
import java.util.List;

import javax.servlet.http.HttpSession;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.multipart.MultipartFile;

import kr.co.koitt.join.MemberVO;
import kr.co.koitt.subject.SubjectService;
import kr.co.koitt.subject.SubjectVO;
import kr.co.koitt.util.UtilForFile;
import kr.co.koitt.util.UtilForFileLinux;

@Controller
public class LectureController {

	@Autowired
	SubjectService subjectService;

	@Autowired
	LectureService lectureService;
	
	private static final Logger logger = LoggerFactory.getLogger(LectureController.class);

	@RequestMapping(value = "/lecture_write", method = RequestMethod.GET)
	public String lectureWrite(Model model, HttpSession session) {
		logger.info("lectureWrite");
		List<SubjectVO> listSubject = null;
		listSubject = subjectService.selectSubject();
		model.addAttribute("listSubject", listSubject);
		return "teacher/lecture/lecture_write";
	}// lectureWrite

	@RequestMapping(value = "/lecture_insert", method = RequestMethod.POST)
	public void LectureInsert(LectureVO vo, PrintWriter out) {
		logger.info("LectureInsert");
		int count = 0;
		vo.setLecture_image_name(vo.getImage_file().getOriginalFilename());
		count = lectureService.teacher_lecture_insert(vo);
		// atch_file start =====
		String upFilePath = "";
		MultipartFile file = null;
		file = vo.getImage_file();
		if (vo != null && file != null && file.getOriginalFilename() != null
				&& file.getOriginalFilename().length() > 0) {
			upFilePath = UtilForFile.fileUpByType(file, "lecture", vo.getLecture_no());
			//upFilePath = UtilForFileLinux.fileUpByType(file, "lecture", vo.getLecture_no());
			vo.setLecture_image_name(upFilePath);
		} // if
		// atch_file end =====
		count = lectureService.file_path_update(vo);
		out.print(count);
		out.flush();
		out.close();
	}// LectureInsert

	@RequestMapping(value = "/lecture_list", method = RequestMethod.GET)
	public String list(Model model, LectureVO vo, HttpSession session) {
		logger.info("list");
		MemberVO mvo = (MemberVO) session.getAttribute("memberVO");
		List<LectureVO> lectureList = null;
		lectureList = lectureService.lectureList(mvo);
		model.addAttribute("LectureList", lectureList);
		return "teacher/lecture/lecture_list";
	}// list

	@RequestMapping(value = "/lecture_detail", method = RequestMethod.GET)
	public String detail(Model model, LectureVO vo) {
		logger.info("detail");
		vo = lectureService.lecture_detail(vo);
		model.addAttribute("detailVO", vo);
		return "teacher/lecture/lecture_detail";
	}// detail

	@RequestMapping(value = "/lecture_modify", method = RequestMethod.GET)
	public String modifyForm(Model model, LectureVO vo) {
		logger.info("modifyForm");
		vo = lectureService.lecture_detail(vo);
		model.addAttribute("detailVO", vo);
		return "teacher/lecture/lecture_modify";
	}// modifyForm
	
	@RequestMapping(value = "/lecture_update", method = RequestMethod.POST)
	public void update(LectureVO vo, PrintWriter out) {
		logger.info("update");
		int cnt = 0;
		// atch_file start =====
		String upFilePath = "";
		MultipartFile file = null;
		file = vo.getImage_file();
		if (vo != null && file != null && file.getOriginalFilename() != null
				&& file.getOriginalFilename().length() > 0) {
			upFilePath = UtilForFile.fileUpByType(file, "lecture", vo.getLecture_no());
			logger.info("update"+vo.getLecture_no());
			vo.setLecture_image_name(upFilePath);
		} // if
		// atch_file end =====
		cnt = lectureService.lecture_update(vo);
		out.print(cnt);
		out.flush();
		out.close();
	}// update

	@RequestMapping(value = "/lecture_delete", method = RequestMethod.POST)
	public void delete(LectureVO vo, PrintWriter out) {
		logger.info("delete");
		int cnt = 0;
		cnt = lectureService.lecture_delete(vo);
		out.print(cnt);
		out.flush();
		out.close();
	}// delete

	/////////////////////////////////chapter/////////////////////////////////
	@RequestMapping(value = "/chapter_write", method = RequestMethod.GET)
	public String chapterWrite(LectureVO vo, Model model) {
		logger.info("chapterWrite");
		vo = lectureService.selectDetail(vo);
		model.addAttribute("SelectDetail", vo);
		//chapter list
		List<ChapterVO> chapterList = null;
		chapterList = lectureService.chapterList(vo);
		model.addAttribute("ChapterList", chapterList);
		return "teacher/lecture/chapter_write";
	}// chapterWrite 챕터화면에서 강의정보 불러오기

	@RequestMapping(value = "/chapter_insert", method = RequestMethod.POST)
	public void ChapterInsert(ChapterVO vo, PrintWriter out) {
		logger.info("ChapterInsert");
		int count = 0;
		ArrayList<ChapterVO> chapterList = new ArrayList<ChapterVO>();
		vo.setLecture_no(vo.getLecture_no());
		vo.setChapter_title(vo.getChapter_title()); chapterList.add(vo);
		count = lectureService.chapter_insert(chapterList);
		out.print(count);
		out.flush();
		out.close();
	}// ChapterInsert
	
	@RequestMapping(value = "/chapter_modify", method = RequestMethod.GET)
	public String chapterModify(Model model, ChapterVO vo, LectureVO lvo) {
		logger.info("chapterModify");
		vo = lectureService.chapter_modify(vo);
		model.addAttribute("chapterDetail", vo);
		//chapter list
		List<ChapterVO> chapterList = null;
		chapterList = lectureService.chapterList(lvo);
		model.addAttribute("ChapterList", chapterList);
		return "teacher/lecture/chapter_modify";
	}// chapterModify

	@RequestMapping(value = "/chapter_update", method = RequestMethod.POST)
	public void chapterUpdate(ChapterVO vo, PrintWriter out) {
		logger.info("chapterUpdate");
		int cnt = 0;
		cnt = lectureService.chapter_update(vo);
		out.print(cnt);
		out.flush();
		out.close();
	}// chapterUpdate
	
	@RequestMapping(value = "/chapter_delete", method = RequestMethod.POST)
	public void chapterDelete(ChapterVO vo, PrintWriter out) {
		logger.info("chapterDelete");
		int cnt = 0;
		cnt = lectureService.chapter_delete(vo);
		out.print(cnt);
		out.flush();
		out.close();
	}// chapterDelete
	
}
