package kr.co.koitt;

import java.util.List;

import org.apache.ibatis.session.SqlSession;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import kr.co.koitt.lecture.LectureVO;
import kr.co.koitt.util.SearchVO;

@Repository
public class MainLectureDAO {
	
	@Autowired
	SqlSession sqlSession;

	public List<LectureVO> lectureList(SearchVO searchVO) {
		List<LectureVO> mainLectureList = null;
		mainLectureList = sqlSession.selectList("MainLectureMapper.LectureList", searchVO);
		return mainLectureList;
	}//lectureList
	
	public int listCnt(SearchVO searchVO) {
		int totalCount = 0;
		totalCount = sqlSession.selectOne("MainLectureMapper.listCnt", searchVO);
		return totalCount;
	}//listCnt


}
