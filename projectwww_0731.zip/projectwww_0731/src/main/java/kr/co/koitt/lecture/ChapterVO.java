package kr.co.koitt.lecture;

public class ChapterVO {
	private String chapter_no;
	private String lecture_no;
	private String chapter_title;
	private String chapter_contents;
	private String chapter_date;
	
	public String getChapter_no() {
		return chapter_no;
	}
	public void setChapter_no(String chapter_no) {
		this.chapter_no = chapter_no;
	}
	public String getLecture_no() {
		return lecture_no;
	}
	public void setLecture_no(String lecture_no) {
		this.lecture_no = lecture_no;
	}
	public String getChapter_title() {
		return chapter_title;
	}
	public void setChapter_title(String chapter_title) {
		this.chapter_title = chapter_title;
	}
	public String getChapter_contents() {
		return chapter_contents;
	}
	public void setChapter_contents(String chapter_contents) {
		this.chapter_contents = chapter_contents;
	}
	public String getChapter_date() {
		return chapter_date;
	}
	public void setChapter_date(String chapter_date) {
		this.chapter_date = chapter_date;
	}
	
}
