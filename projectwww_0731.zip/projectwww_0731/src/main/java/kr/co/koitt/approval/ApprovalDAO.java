package kr.co.koitt.approval;

import java.util.List;

import org.apache.ibatis.session.SqlSession;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import kr.co.koitt.join.MemberVO;

@Repository
public class ApprovalDAO {

	@Autowired
	SqlSession sqlSession;
	
	public List<ApprovalVO> selectTeacher() {
		List<ApprovalVO> approvalList = null;
		approvalList = sqlSession.selectList("AdminMapper.SelectTeacher");
		return approvalList;
	}//selectTeacher

	public int levelup(MemberVO vo) {
		int cnt = 0;
		cnt = sqlSession.update("AdminMapper.levelup",vo);
		return cnt;
	}

	public ApprovalVO approval_detail(ApprovalVO vo) {
		vo = sqlSession.selectOne("AdminMapper.approval_detail", vo);
		return vo;
	}//approval_detail

}
