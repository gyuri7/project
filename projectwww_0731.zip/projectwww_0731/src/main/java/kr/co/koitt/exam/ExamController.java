package kr.co.koitt.exam;

import java.util.List;

import javax.servlet.http.HttpSession;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;

import kr.co.koitt.join.ExamineeVO;
import kr.co.koitt.question.ExampleVO;
import kr.co.koitt.question.QuestionVO;

@Controller
public class ExamController {

	@Autowired
	ExamService examService; 

	private static final Logger logger = LoggerFactory.getLogger(ExamController.class);
	
	@RequestMapping(value = "/exam_notice", method = RequestMethod.GET)
	public String examnotice(Model model) {//calling question insert form
		logger.info("===examnotice===");
		return "exam/exam_notice"; 
	}//examList
	
	@RequestMapping(value = "/exam/exam_test", method = RequestMethod.GET)
	public String examList(HttpSession session, Model model, QuestionVO vo) {//calling question insert form
		logger.info("===examList===");
		ExamineeVO examVO = (ExamineeVO) session.getAttribute("ExamineeVO");

		List<QuestionVO> questionList = null;
		questionList = examService.selectQuestion(examVO);
		model.addAttribute("questionList", questionList);

//		List<ExamVO> examList = null;
//		examList = examService.selectExam();
//		model.addAttribute("examList", examList);
		
		logger.info("===exampleList===");
		List<ExampleVO> exampleList = null;
		exampleList = examService.exampleList(questionList);
		model.addAttribute("ExampleList", exampleList);
		return "exam/exam_test"; 
	}//examList
	
	
	


}
