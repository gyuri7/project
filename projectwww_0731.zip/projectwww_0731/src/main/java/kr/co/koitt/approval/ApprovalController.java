package kr.co.koitt.approval;

import java.io.PrintWriter;
import java.util.List;

import org.apache.ibatis.session.SqlSession;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.multipart.MultipartFile;

import kr.co.koitt.join.MemberVO;
import kr.co.koitt.lecture.LectureVO;
import kr.co.koitt.util.UtilForFile;


@Controller
public class ApprovalController {
	
	@Autowired
	SqlSession sqlSession;
	
	@Autowired
	ApprovalService approvalservice;
	
	private static final Logger logger = LoggerFactory.getLogger(ApprovalController.class);
	
	@RequestMapping(value = "/admin/approval", method = RequestMethod.GET)
	public String approval(ApprovalVO vo, Model model) {
		logger.info("=== approval ===");
		List<ApprovalVO> approvalList = null;
		approvalList = approvalservice.selectTeacher();
		model.addAttribute("approvalList", approvalList);
		return "admin/approval";
	}//approvalList
	
	@RequestMapping(value = "/admin/approval_detail", method = RequestMethod.GET)
	public String detail(ApprovalVO vo, Model model) {
		logger.info("=== detail ===");
		vo = approvalservice.approval_detail(vo);
		model.addAttribute("ApprovalVO", vo);
		return "admin/approval_detail";
	}//approvalDetail
	
	@RequestMapping(value = "/levelup", method = RequestMethod.POST)
	public void update(MemberVO vo, PrintWriter out) {
		logger.info("=== update ===");
		logger.info("=== update ==="+vo.getMember_no());
		int cnt = 0;
		cnt = approvalservice.levelup(vo);
		out.print(cnt);
		out.flush();
		out.close();
	}// update
	
}
