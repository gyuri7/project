package kr.co.koitt.mypage;

import java.util.List;

import org.apache.ibatis.session.SqlSession;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import kr.co.koitt.join.MemberVO;
import kr.co.koitt.lecture.LectureVO;

@Repository 
public class MypageDAO {

	@Autowired
	SqlSession sqlSession;

	public int apply_teacher(MypageVO vo) {
		int count = 0;
		count = sqlSession.insert("MypageMapper.ApplyTeacher", vo);
		return count;
	}//apply_teacher

	public List<MypageVO> TeacherApplyList() {
		List<MypageVO> list = null;
		list = sqlSession.selectList("MypageMapper.TeacherApplyList");
		return list;
	}//TeacherApplyList

	/////////////////////////////수강신청/////////////////////////////
	public int apply_lecture(ApplyLectureVO vo) {
		int count = 0;
		count = sqlSession.insert("MypageMapper.ApplyLeture",vo);
		return count;
	}//apply_lecture

	public List<ApplyLectureVO> myLectureList(MemberVO mvo) {
		List<ApplyLectureVO> myLectureList = null;
		myLectureList = sqlSession.selectList("MypageMapper.MyLectureList", mvo);
		return myLectureList;
	}//myLectureList

	public int apply_delete(ApplyLectureVO vo) {
		int count = 0;
		count = sqlSession.delete("MypageMapper.ApplyDelete",vo);
		return count;
	}//apply_delete

}
