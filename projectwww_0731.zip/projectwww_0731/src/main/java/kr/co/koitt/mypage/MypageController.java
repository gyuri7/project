package kr.co.koitt.mypage;

import java.io.PrintWriter;
import java.util.List;

import javax.servlet.http.HttpSession;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.multipart.MultipartFile;

import kr.co.koitt.join.MemberVO;
import kr.co.koitt.lecture.LectureVO;
import kr.co.koitt.util.UtilForFile;

@Controller
public class MypageController {
	
	private static final Logger logger = LoggerFactory.getLogger(MypageController.class);
	
	@Autowired
	MypageService mypageService;
	
	@RequestMapping(value = "/main/mypage/teacher_apply_list", method = RequestMethod.GET)
	public String list(Model model, MypageVO vo) {
		logger.info("=== list ===");
		List<MypageVO> list =null;
		list = mypageService.TeacherApplyList();
		model.addAttribute("TeacherApplyList",list);
		
		return "main/mypage/teacher_apply_list"; 
	}//list
	
	@RequestMapping(value="/teacher_apply_write", method=RequestMethod.GET)
	public String teacher_apply_write(Model model) {
		logger.info("=== write ===");
		return "main/mypage/teacher_apply_write";
	}//teacher_apply_write
	
	
	@RequestMapping(value = "/apply_teacher", method = RequestMethod.POST)
	public void apply_teacher_insert(MypageVO vo, PrintWriter out) {
		logger.info("=== insert ===");
		int count = 0;
		// image_atch_file start =====
			String upFilePath = "";
			MultipartFile file = null;
			file = vo.getImage_file();
			if (vo != null && file != null && file.getOriginalFilename() != null
					&& file.getOriginalFilename().length() > 0) {
				upFilePath = UtilForFile.fileUpByType(file, "t_img", vo.getMember_no());
				vo.setTeacher_image_name(upFilePath);
			} // if
		// image_atch_file end =====
		// edu_atch_file start =====
			String upFilePath2 = "";
			MultipartFile file2 = null;
			file = vo.getEducation_file();
			if (vo != null && file != null && file.getOriginalFilename() != null
					&& file.getOriginalFilename().length() > 0) {
				upFilePath2 = UtilForFile.fileUpByType(file, "t_edu", vo.getMember_no());
				vo.setTeacher_education_name(upFilePath2);
			} // if
		// edu_atch_file end =====
		count = mypageService.apply_teacher(vo);		
		out.print(count);
		out.flush();
		out.close();
	}//apply_teacher_insert
	
	/////////////////////////////수강신청/////////////////////////////
	@RequestMapping(value = "/apply_lecture", method = RequestMethod.POST)
	public void apply_lecture(ApplyLectureVO vo, PrintWriter out) {
		logger.info("apply_lecture");
		int count = 0;
		count = mypageService.apply_lecture(vo);
		out.print(count);
		out.flush();
		out.close();
	}// apply_lecture
	
	@RequestMapping(value = "/my_lecture_list", method = RequestMethod.GET)
	public String my_lecture_list(HttpSession session, Model model, ApplyLectureVO vo) {
		logger.info("my_lecture_list");
		MemberVO mvo = (MemberVO) session.getAttribute("memberVO");
		List<ApplyLectureVO> myLectureList = null;
		myLectureList = mypageService.myLectureList(mvo);
		model.addAttribute("MyLectureList", myLectureList);
		return "main/mypage/my_lecture_list";
	}// my_lecture_list
	
	@RequestMapping(value = "/apply_delete", method = RequestMethod.POST)
	public void apply_delete(ApplyLectureVO vo, PrintWriter out) {
		logger.info("apply_delete");
		int count = 0;
		count = mypageService.apply_delete(vo);
		out.print(count);
		out.flush();
		out.close();
	}// apply_delete

}
