package kr.co.koitt.company;

public class ExcelTestVO {
	
	private String examinee_name;
	private String examinee_tel;
	private String examinee_email;
	
	public String getExaminee_name() {
		return examinee_name;
	}
	public void setExaminee_name(String examinee_name) {
		this.examinee_name = examinee_name;
	}
	public String getExaminee_tel() {
		return examinee_tel;
	}
	public void setExaminee_tel(String examinee_tel) {
		this.examinee_tel = examinee_tel;
	}
	public String getExaminee_email() {
		return examinee_email;
	}
	public void setExaminee_email(String examinee_email) {
		this.examinee_email = examinee_email;
	}	
	
}
