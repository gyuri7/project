package kr.co.koitt.board;

import java.io.PrintWriter;
import java.util.List;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;

import kr.co.koitt.lecture.LectureVO;

@Controller
public class BoardController {

	@Autowired
	BoardService boardService;
	
	private static final Logger logger = LoggerFactory.getLogger(BoardController.class);
	
	@RequestMapping(value = "/main/board/write", method = RequestMethod.GET)
	public String formBoardWrite() {
		logger.info("=== formBoardWrite ===");
		return "main/board/write"; 
	}//BoardWrite
	
	@RequestMapping(value = "/main/board/insert", method = RequestMethod.POST)
	public void boardInsert(PrintWriter out, BoardVO vo){
		logger.info("=== formBoardWrite ===");
		logger.info("=== formBoardWrite ==="+vo.getBoard_title());
		int count = 0;			
		count = boardService.insert(vo);
		out.print(count);
		out.flush();
		out.close();
	}//BoardInsert
	
	@RequestMapping(value = "/main/board/list", method = RequestMethod.GET)
	public String list(Model model, BoardVO vo) {
		logger.info("=== list ===");
		List<BoardVO> list =null;
		list = boardService.List();
		model.addAttribute("List",list);
		return "main/board/list"; 
	}//list
	
	@RequestMapping(value = "/main/board/detail", method = RequestMethod.GET)
	public String detail(Model model, BoardVO vo) {
		logger.info("=== detail ===");
		vo = boardService.detail(vo);
		model.addAttribute("detailVO", vo);
		return "main/board/detail";
	}//detail
	
	@RequestMapping(value = "/board_delete", method = RequestMethod.POST)
	public void delete(BoardVO vo, PrintWriter out) {
		logger.info("=== delete ===");
		int count = 0;
		count = boardService.delete(vo);
		out.print(count);
		out.flush();
		out.close();
	}// delete
	
	
	
}//class
