package kr.co.koitt.mypage;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import kr.co.koitt.join.MemberVO;
import kr.co.koitt.lecture.LectureVO;

@Service
public class MypageService {
	
	@Autowired
	MypageDAO dao;

	public int apply_teacher(MypageVO vo) {
		int count = 0;
		count = dao.apply_teacher(vo);
		return count;
	}

	public List<MypageVO> TeacherApplyList() {
		List<MypageVO> list = null;
		list = dao.TeacherApplyList();
		return list;
	}//TeacherApplyList

	/////////////////////////////수강신청/////////////////////////////
	public int apply_lecture(ApplyLectureVO vo) {
		int count = 0;
		count = dao.apply_lecture(vo);
		return count;
	}//apply_lecture

	public List<ApplyLectureVO> myLectureList(MemberVO mvo) {
		List<ApplyLectureVO> myLectureList = null;
		myLectureList = dao.myLectureList(mvo);
		return myLectureList;
	}//myLectureList

	public int apply_delete(ApplyLectureVO vo) {
		int count = 0;
		count = dao.apply_delete(vo);
		return count;
	}//apply_delete

		
}
