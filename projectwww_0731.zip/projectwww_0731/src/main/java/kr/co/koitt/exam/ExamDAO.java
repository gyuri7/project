package kr.co.koitt.exam;

import java.util.List;

import org.apache.ibatis.session.SqlSession;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import kr.co.koitt.join.ExamineeVO;
import kr.co.koitt.question.ExampleVO;
import kr.co.koitt.question.QuestionVO;

@Repository
public class ExamDAO {

	@Autowired
	SqlSession sqlSession;
	
	public List<ExamVO> selectExam() {
		List<ExamVO> examList = null;
		examList = sqlSession.selectList("ExamMapper.selectExam");
		return examList;
	}

	public List<ExampleVO> exampleList(List<QuestionVO> questionList) {
		List<ExampleVO> exampleList = null;
		exampleList = sqlSession.selectList("ExamMapper.exampleList", questionList);
		return exampleList;
	}

	public List<QuestionVO> selectQuestion(ExamineeVO examVO) {
		List<QuestionVO> questionList = null;
		questionList = sqlSession.selectList("ExamMapper.selectQuestion", examVO);
		return questionList;
	}
	
}
