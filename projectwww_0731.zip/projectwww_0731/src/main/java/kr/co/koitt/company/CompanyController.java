package kr.co.koitt.company;


import java.io.IOException;
import java.io.PrintWriter;
import java.util.List;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.multipart.MultipartFile;
import org.springframework.web.multipart.MultipartHttpServletRequest;

import kr.co.koitt.subject.SubjectService;
import kr.co.koitt.subject.SubjectVO;
import kr.co.koitt.util.UtilForFile;

@Controller
public class CompanyController {
	
	@Autowired
    SubjectService subjectService;
	
	@Autowired
	CompanyService companyService; 
	
	@Autowired
	ExcelRegistrationExaminee excelService;

private static final Logger logger = LoggerFactory.getLogger(CompanyController.class);
	
	@RequestMapping(value = "/company/test_write", method = RequestMethod.GET)
	public String formTestWrite(Model model) {//calling question insert form
		logger.info("=== formTestWrite ===");
		List<SubjectVO> listSubject = null;
		listSubject = subjectService.selectSubject();
		model.addAttribute("listSubject", listSubject);

		return "company/test_write"; 
	}//formTestWrite, 과목대분류

	@RequestMapping(value = "/company/test_insert", method = RequestMethod.POST)
	public void testInsert(PrintWriter out, CompanyVO vo) {//question insert
		logger.info("=== testInsert ===");
		int successCnt = 0;
		
		///////////////////////////////////////////
		String upFilePath = "";//in
		MultipartFile file = null;
		file = vo.getExcel_file();
		if (vo != null && file != null && file.getOriginalFilename() != null && file.getOriginalFilename().length() > 0) {
			upFilePath = UtilForFile.fileUpByType(file, "excel_file", vo.getTest_no());
			vo.setQuestion_examinee_list(upFilePath);
			logger.info("=== !!! ===" + upFilePath);
			List<ExcelTestVO> list = excelService.xlsxExcelReader(file);
			System.out.println(list);
			successCnt = companyService.excelinsert(list);	
		} // in	
		/////////////////////////////////////엑셀
		successCnt = companyService.insert(vo);	
		out.print(successCnt);
		out.flush();
		out.close();
	}//testInsert
			
	@RequestMapping(value = "/company/test_list", method = RequestMethod.GET)
	public String testlist(Model model, CompanyVO vo) {
		logger.info("=== list ===");
		List<CompanyVO> list =null;
		list = subjectService.CompanyList();
		model.addAttribute("CompanyList",list);
		
		return "company/test_list"; 
	}//testlist
	
	@RequestMapping(value = "/company/test_detail", method = RequestMethod.GET)
	public String testdetail(Model model, CompanyVO vo) {
		logger.info("=== testdetail ===");
		vo = companyService.detail(vo);
		model.addAttribute("detailVO", vo);
		System.out.println(vo);
		return "company/test_detail"; 
	}//testdetail
	
	@RequestMapping(value="/company/delete", method=RequestMethod.POST)
	public void testdelete(CompanyVO vo, PrintWriter out) {
		logger.info("=== testdelete ===");
		int successCnt = 0;
		successCnt = companyService.delete(vo);
		out.println(successCnt);
		out.flush();
		out.close();
	}//testdelete
	
	@RequestMapping(value="/company/test_modify", method=RequestMethod.GET)
	public String testmodify(Model model, CompanyVO vo) {
		logger.info("=== testmodify ===");
		vo = companyService.detail(vo);
		model.addAttribute("detailVO", vo);
		return "company/test_modify";
	}//testmodify
	
	@RequestMapping(value = "/company/test_update", method = RequestMethod.POST)
	public void testupdate(PrintWriter out, CompanyVO vo) throws IOException {//question insert
		logger.info("=== testupdate ===");
		int successCnt = 0;
		successCnt = companyService.update(vo);
		out.print(successCnt);
		out.flush();
		out.close();
	}//questionInsert

}	


