package kr.co.koitt.lecture;

import org.springframework.web.multipart.MultipartFile;

public class LectureVO {
	private String lecture_no;
	private String member_no;
	private String subject_no;
	private String lecture_name;
	private String lecture_difficulty;
	private String lecture_period;
	private String lecture_introduction;
	private String lecture_date;
	private String lecture_image_name;
	private MultipartFile image_file;
	
	private String teacher_name;
	private String subject_name;
	
	private String my_apply_yn;

	public String getLecture_no() {
		return lecture_no;
	}

	public void setLecture_no(String lecture_no) {
		this.lecture_no = lecture_no;
	}

	public String getMember_no() {
		return member_no;
	}

	public void setMember_no(String member_no) {
		this.member_no = member_no;
	}

	public String getSubject_no() {
		return subject_no;
	}

	public void setSubject_no(String subject_no) {
		this.subject_no = subject_no;
	}

	public String getLecture_name() {
		return lecture_name;
	}

	public void setLecture_name(String lecture_name) {
		this.lecture_name = lecture_name;
	}

	public String getLecture_difficulty() {
		return lecture_difficulty;
	}

	public void setLecture_difficulty(String lecture_difficulty) {
		this.lecture_difficulty = lecture_difficulty;
	}

	public String getLecture_period() {
		return lecture_period;
	}

	public void setLecture_period(String lecture_period) {
		this.lecture_period = lecture_period;
	}

	public String getLecture_introduction() {
		return lecture_introduction;
	}

	public void setLecture_introduction(String lecture_introduction) {
		this.lecture_introduction = lecture_introduction;
	}

	public String getLecture_date() {
		return lecture_date;
	}

	public void setLecture_date(String lecture_date) {
		this.lecture_date = lecture_date;
	}

	public String getLecture_image_name() {
		return lecture_image_name;
	}

	public void setLecture_image_name(String lecture_image_name) {
		this.lecture_image_name = lecture_image_name;
	}

	public MultipartFile getImage_file() {
		return image_file;
	}

	public void setImage_file(MultipartFile image_file) {
		this.image_file = image_file;
	}

	public String getTeacher_name() {
		return teacher_name;
	}

	public void setTeacher_name(String teacher_name) {
		this.teacher_name = teacher_name;
	}

	public String getSubject_name() {
		return subject_name;
	}

	public void setSubject_name(String subject_name) {
		this.subject_name = subject_name;
	}

	public String getMy_apply_yn() {
		return my_apply_yn;
	}

	public void setMy_apply_yn(String my_apply_yn) {
		this.my_apply_yn = my_apply_yn;
	}
	
}
