package kr.co.koitt.approval;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import kr.co.koitt.join.MemberVO;


@Service
public class ApprovalService {
	
	@Autowired
	ApprovalDAO dao;

	public List<ApprovalVO> selectTeacher() {
		List<ApprovalVO> approvalList = null;
		approvalList = dao.selectTeacher();
		return approvalList;
	}//selectTeacher

	public int levelup(MemberVO vo) {
		int cnt = 0;
		cnt = dao.levelup(vo);
		return cnt;
	}//update

	public ApprovalVO approval_detail(ApprovalVO vo) {
		vo = dao.approval_detail(vo);
		return vo;
	}//approval_detail

}
