package kr.co.koitt.mypage;

public class ApplyLectureVO {
	private String apply_lecture_no;
	private String member_no;
	private String lecture_no;
	private String apply_lecture_date;
	
	private String lecture_name;
	private String lecture_period;
	private String teacher_name;
	
	public String getApply_lecture_no() {
		return apply_lecture_no;
	}
	public void setApply_lecture_no(String apply_lecture_no) {
		this.apply_lecture_no = apply_lecture_no;
	}
	public String getMember_no() {
		return member_no;
	}
	public void setMember_no(String member_no) {
		this.member_no = member_no;
	}
	public String getLecture_no() {
		return lecture_no;
	}
	public void setLecture_no(String lecture_no) {
		this.lecture_no = lecture_no;
	}
	public String getApply_lecture_date() {
		return apply_lecture_date;
	}
	public void setApply_lecture_date(String apply_lecture_date) {
		this.apply_lecture_date = apply_lecture_date;
	}
	public String getLecture_name() {
		return lecture_name;
	}
	public void setLecture_name(String lecture_name) {
		this.lecture_name = lecture_name;
	}
	public String getLecture_period() {
		return lecture_period;
	}
	public void setLecture_period(String lecture_period) {
		this.lecture_period = lecture_period;
	}
	public String getTeacher_name() {
		return teacher_name;
	}
	public void setTeacher_name(String teacher_name) {
		this.teacher_name = teacher_name;
	}
	
}
