package kr.co.koitt.company;

import java.util.List;

import org.apache.ibatis.session.SqlSession;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;


@Repository
public class CompanyDAO {
	
	@Autowired
	SqlSession sqlSession;
	
	public int insert(CompanyVO vo) {
		int successCnt = 0;
		successCnt = sqlSession.insert("CompanyMapper.companyInsert", vo);
		return successCnt;
	}
	
	public int excelinsert(List<ExcelTestVO> list) {
		int successCnt = 0;
		successCnt = sqlSession.insert("CompanyMapper.excelInsert", list);
		return successCnt;
	}//insert

	public CompanyVO detail(CompanyVO vo) {
		vo = sqlSession.selectOne("CompanyMapper.companyDetail", vo);
		return vo;
	}//detail

	public int delete(CompanyVO vo) {
		int successCnt = 0;
		successCnt = sqlSession.delete("CompanyMapper.companyDelete",vo);
		return successCnt;
	}//detail

	public int update(CompanyVO vo) {
		int successCnt = 0;
		successCnt = sqlSession.update("CompanyMapper.CompanyUpdate",vo);
		return successCnt;
	}

	
	
	
}
