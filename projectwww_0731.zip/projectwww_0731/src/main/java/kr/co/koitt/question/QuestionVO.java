package kr.co.koitt.question;

public class QuestionVO {
	private String question_no;
	private String subject_no;
	private String question;
	private String question_answer;
	private String question_explain;
	private String member_no;
	private String teacher_name;
	private String subject_name;
	private String []example_sequence;
	private String []example;	
	
	public String[] getExample_sequence() {
		return example_sequence;
	}
	public void setExample_sequence(String[] example_sequence) {
		this.example_sequence = example_sequence;
	}
	public String[] getExample() {
		return example;
	}
	public void setExample(String[] example) {
		this.example = example;
	}
	public String getSubject_name() {
		return subject_name;
	}
	public void setSubject_name(String subject_name) {
		this.subject_name = subject_name;
	}
	public String getQuestion_no() {
		return question_no;
	}
	public void setQuestion_no(String question_no) {
		this.question_no = question_no;
	}
	public String getSubject_no() {
		return subject_no;
	}
	public void setSubject_no(String subject_no) {
		this.subject_no = subject_no;
	}
	public String getQuestion() {
		return question;
	}
	public void setQuestion(String question) {
		this.question = question;
	}
	public String getQuestion_answer() {
		return question_answer;
	}
	public void setQuestion_answer(String question_answer) {
		this.question_answer = question_answer;
	}
	public String getQuestion_explain() {
		return question_explain;
	}
	public void setQuestion_explain(String question_explain) {
		this.question_explain = question_explain;
	}
	public String getMember_no() {
		return member_no;
	}
	public void setMember_no(String member_no) {
		this.member_no = member_no;
	}
	public String getTeacher_name() {
		return teacher_name;
	}
	public void setTeacher_name(String teacher_name) {
		this.teacher_name = teacher_name;
	}
	
}
