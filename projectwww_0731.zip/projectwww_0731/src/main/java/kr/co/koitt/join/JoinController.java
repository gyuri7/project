package kr.co.koitt.join;

import java.io.PrintWriter;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;

import kr.co.koitt.question.QuestionController;

@Controller
public class JoinController {
	
	@Autowired
	JoinService joinService;
	
	private static final Logger logger = LoggerFactory.getLogger(JoinController.class);
	
	@RequestMapping(value="/join", method=RequestMethod.GET)
	public String joinForm() {
		logger.info("joinForm");
		return "main/join";
	}//joinForm
	
	@RequestMapping(value="/joinpro", method=RequestMethod.POST)
	public void joinPro(MemberVO vo, PrintWriter out) {
		logger.info("joinPro");
		int cnt = 0;
		cnt = joinService.join_insert(vo);
		out.print(cnt);
		out.flush();
		out.close();
	}//joinPro
	
	@RequestMapping(value="/idcheck", method=RequestMethod.POST)
	public void idCheck(MemberVO vo, PrintWriter out) {
		logger.info("idCheck");
		int cnt = 0;
		cnt = joinService.idCheck(vo);
		out.print(cnt);
		out.flush();
		out.close();
	}//idCheck

}
