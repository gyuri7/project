package kr.co.koitt;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import kr.co.koitt.lecture.LectureVO;

@Service
public class MainLectureService {
	
	@Autowired
	MainLectureDAO dao;

	public List<LectureVO> selectLecture() {
		List<LectureVO> mainLectureList = null;
		mainLectureList = dao.selectLecture();
		return mainLectureList;
	}//selectLecture

}
