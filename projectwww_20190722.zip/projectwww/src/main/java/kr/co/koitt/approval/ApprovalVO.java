package kr.co.koitt.approval;

public class ApprovalVO {
	private String member_no;
	private String teacher_education;
	private String teacher_devel_career;
	private String teacher_lecture_career;
	private String teacher_image;
	private String teacher_apply_date;
	private String teacher_apply_status;
	private String member_id;
	
	public String getMember_no() {
		return member_no;
	}
	public void setMember_no(String member_no) {
		this.member_no = member_no;
	}
	public String getTeacher_education() {
		return teacher_education;
	}
	public void setTeacher_education(String teacher_education) {
		this.teacher_education = teacher_education;
	}
	public String getTeacher_devel_career() {
		return teacher_devel_career;
	}
	public void setTeacher_devel_career(String teacher_devel_career) {
		this.teacher_devel_career = teacher_devel_career;
	}
	public String getTeacher_lecture_career() {
		return teacher_lecture_career;
	}
	public void setTeacher_lecture_career(String teacher_lecture_career) {
		this.teacher_lecture_career = teacher_lecture_career;
	}
	public String getTeacher_image() {
		return teacher_image;
	}
	public void setTeacher_image(String teacher_image) {
		this.teacher_image = teacher_image;
	}
	public String getTeacher_apply_date() {
		return teacher_apply_date;
	}
	public void setTeacher_apply_date(String teacher_apply_date) {
		this.teacher_apply_date = teacher_apply_date;
	}
	public String getTeacher_apply_status() {
		return teacher_apply_status;
	}
	public void setTeacher_apply_status(String teacher_apply_status) {
		this.teacher_apply_status = teacher_apply_status;
	}
	public String getMember_id() {
		return member_id;
	}
	public void setMember_id(String member_id) {
		this.member_id = member_id;
	}
}
