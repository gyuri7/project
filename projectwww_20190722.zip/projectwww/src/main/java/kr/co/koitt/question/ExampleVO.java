package kr.co.koitt.question;

public class ExampleVO {
	private String example_no;
	private String question_no;
	private String example_sequence;
	private String example;
	
	public String getExample_no() {
		return example_no;
	}
	public void setExample_no(String example_no) {
		this.example_no = example_no;
	}
	public String getQuestion_no() {
		return question_no;
	}
	public void setQuestion_no(String question_no) {
		this.question_no = question_no;
	}
	public String getExample_sequence() {
		return example_sequence;
	}
	public void setExample_sequence(String example_sequence) {
		this.example_sequence = example_sequence;
	}
	public String getExample() {
		return example;
	}
	public void setExample(String example) {
		this.example = example;
	}

}
