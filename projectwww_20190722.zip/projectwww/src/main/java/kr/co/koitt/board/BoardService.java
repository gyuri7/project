package kr.co.koitt.board;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import kr.co.koitt.mypage.MypageVO;


@Service
public class BoardService {

	@Autowired
	BoardDAO dao;
	
	public int insert(BoardVO vo) {
		int count = 0;
		count = dao.insert(vo);
		return count;
	}//insert

	public List<BoardVO> List() {
		List<BoardVO> list = null;
		list = dao.List();
		return list;
	}//list


}//class
