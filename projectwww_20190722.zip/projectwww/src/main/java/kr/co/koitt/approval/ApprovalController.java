package kr.co.koitt.approval;

import java.util.List;

import org.apache.ibatis.session.SqlSession;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;


@Controller
public class ApprovalController {
	
	@Autowired
	SqlSession sqlSession;
	
	@Autowired
	ApprovalService approvalservice;
	
	private static final Logger logger = LoggerFactory.getLogger(ApprovalController.class);
	
	@RequestMapping(value = "/admin/approval", method = RequestMethod.GET)
	public String approval(ApprovalVO vo, Model model) {
		logger.info("approval");
		List<ApprovalVO> approvalList = null;
		approvalList = approvalservice.selectTeacher();
		model.addAttribute("approvalList", approvalList);
		return "admin/approval";
	}//approval
	
	@RequestMapping(value = "/admin/approval_detail", method = RequestMethod.GET)
	public String detail(ApprovalVO vo, Model model) {
		logger.info("detail");
		List<ApprovalVO> detailList = null;
		detailList = approvalservice.selectDetail();
		model.addAttribute("detailList", detailList);
		return "admin/approval_detail";
	}//approval
	
}
