package kr.co.koitt.subject;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import kr.co.koitt.question.QuestionVO;

@Service
public class SubjectService {
	@Autowired
	SubjectDAO dao;
	
	public List<SubjectVO> selectSubject() {
		List<SubjectVO> listSubject = null;
		listSubject = dao.selectSubject();
		return listSubject ;
	}

	public List<QuestionVO> QuestionList() {
		List<QuestionVO> list =null;
		list = dao.QuestionList();
		return list;
	}

	public int insert(QuestionVO vo) {
		int successCnt = 0;
		successCnt = dao.insert(vo);
		return successCnt;
	}

}
