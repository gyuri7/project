package kr.co.koitt.subject;

import java.util.List;

import org.apache.ibatis.session.SqlSession;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import kr.co.koitt.question.QuestionVO;

@Repository
public class SubjectDAO {
	@Autowired
	SqlSession sqlSession;
	
	public List<SubjectVO> selectSubject() {
		List<SubjectVO> listSubject = null;
		listSubject = sqlSession.selectList("SubjectMapper.selectSubject");
		return listSubject ;
	}

	public List<QuestionVO> QuestionList() {
		List<QuestionVO> list =null;
		list = sqlSession.selectList("QuestionMapper.QuestionList");
		return list;
	}

	public int insert(QuestionVO vo) {
		int successCnt = 0;
		successCnt = sqlSession.insert("QuestionMapper.QuestionInsert",vo);
		return successCnt;
	}
}
