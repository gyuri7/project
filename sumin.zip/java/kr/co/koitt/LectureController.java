package kr.co.koitt;

import org.apache.ibatis.session.SqlSession;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;

@Controller
public class LectureController {
	
	@Autowired
	SqlSession sqlSession;
	
	private static final Logger logger = LoggerFactory.getLogger(LectureController.class);
	
	@RequestMapping(value = "/lecture/lecture_list", method = RequestMethod.GET)
	public String lecture_list() {
		return "main/lecture/lecture_list";
	}
	
	@RequestMapping(value = "/main/lecture/lecture_detail", method = RequestMethod.GET)
	public String lecture_detail() {
		return "main/lecture/lecture_detail";
	}
	
	@RequestMapping(value = "/teacher/lecture/lecture_insert", method = RequestMethod.GET)
	public String lecture_insert() {
		return "teacher/lecture/lecture_insert";
	}
	
}
