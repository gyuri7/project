package kr.co.koitt.question;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;



@Service
public class QuestionService {
	
	@Autowired
	QuestionDAO dao;

	public List<QuestionVO> QuestionList(){
		List<QuestionVO> list = null;
		list = dao.QuestionList();
		return list;
	}//QuestionList

	public int insert(QuestionVO vo) {
		int successCnt = 0;
		successCnt = dao.insert(vo);
		return successCnt;
	}

	public QuestionVO detail(QuestionVO vo) {
		vo = dao.detail(vo);
		return vo;
	}//detail

	

	
	
}
