package kr.co.koitt;

public class LectureVO {
	
	private String lecture_name;
	private String lecture_image;
	private String subject;
	private String lecture_difficulty;
	private String lecture_chapter_title;
	private String lecture_chapter_contents;
	private String lecture_period;
	private String lecture_payment;
	private String lecture_book;
	private String lecture_introduction;
	
	public String getLecture_name() {
		return lecture_name;
	}
	public void setLecture_name(String lecture_name) {
		this.lecture_name = lecture_name;
	}
	public String getLecture_image() {
		return lecture_image;
	}
	public void setLecture_image(String lecture_image) {
		this.lecture_image = lecture_image;
	}
	public String getSubject() {
		return subject;
	}
	public void setSubject(String subject) {
		this.subject = subject;
	}
	public String getLecture_difficulty() {
		return lecture_difficulty;
	}
	public void setLecture_difficulty(String lecture_difficulty) {
		this.lecture_difficulty = lecture_difficulty;
	}
	public String getLecture_chapter_title() {
		return lecture_chapter_title;
	}
	public void setLecture_chapter_title(String lecture_chapter_title) {
		this.lecture_chapter_title = lecture_chapter_title;
	}
	public String getLecture_chapter_contents() {
		return lecture_chapter_contents;
	}
	public void setLecture_chapter_contents(String lecture_chapter_contents) {
		this.lecture_chapter_contents = lecture_chapter_contents;
	}
	public String getLecture_period() {
		return lecture_period;
	}
	public void setLecture_period(String lecture_period) {
		this.lecture_period = lecture_period;
	}
	public String getLecture_payment() {
		return lecture_payment;
	}
	public void setLecture_payment(String lecture_payment) {
		this.lecture_payment = lecture_payment;
	}
	public String getLecture_book() {
		return lecture_book;
	}
	public void setLecture_book(String lecture_book) {
		this.lecture_book = lecture_book;
	}
	public String getLecture_introduction() {
		return lecture_introduction;
	}
	public void setLecture_introduction(String lecture_introduction) {
		this.lecture_introduction = lecture_introduction;
	}

}
