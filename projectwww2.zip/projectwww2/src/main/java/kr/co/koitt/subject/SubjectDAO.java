package kr.co.koitt.subject;

import java.util.List;

import org.apache.ibatis.session.SqlSession;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import kr.co.koitt.company.CompanyVO;
import kr.co.koitt.question.QuestionVO;
import kr.co.koitt.teacher.TeacherVO;

@Repository
public class SubjectDAO {
	@Autowired
	SqlSession sqlSession;
	
	public List<SubjectVO> selectSubject() {
		List<SubjectVO> listSubject = null;
		listSubject = sqlSession.selectList("SubjectMapper.selectSubject");
		return listSubject ;
	}

	public List<TeacherVO> lectureList() {
		List<TeacherVO> lectureList = null;
		lectureList = sqlSession.selectList("TeacherMapper.LectureList");
		return lectureList;
	}//lectureList

	public List<CompanyVO> CompanyList() {
		List<CompanyVO> CompanyList = null;
		CompanyList = sqlSession.selectList("CompanyMapper.CompanyList");
		return CompanyList;
	}

	public int update(CompanyVO vo) {
		int successCnt = 0;
		successCnt = sqlSession.update("CompanyMapper.CompanyUpdate", vo);
		return successCnt;
	}//question_update

	public int lecture_update(TeacherVO vo) {
		int cnt = 0;
		cnt = sqlSession.update("TeacherMapper.LectureUpdate",vo);
		return cnt;
	}//lecture_update



}
