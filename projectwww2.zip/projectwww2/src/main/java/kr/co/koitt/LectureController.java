package kr.co.koitt;

import java.util.List;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;

import kr.co.koitt.teacher.TeacherVO;

@Controller
public class LectureController {
	
	@Autowired
	LectureService lectureService;
	
	private static final Logger logger = LoggerFactory.getLogger(LectureController.class);
	
	@RequestMapping(value = "/main_lecture", method = RequestMethod.GET)
	public String main_lecture(TeacherVO vo, Model model) {
		logger.info("main_lecture");
		List<TeacherVO> mainLectureList = null;
		mainLectureList = lectureService.selectLecture();
		model.addAttribute("MainLectureList", mainLectureList);
		return "main/lecture/lecture_list";
	}//main_lecture
	
}
