package kr.co.koitt;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import kr.co.koitt.teacher.TeacherVO;

@Service
public class LectureService {
	
	@Autowired
	LectureDAO dao;

	public List<TeacherVO> selectLecture() {
		List<TeacherVO> mainLectureList = null;
		mainLectureList = dao.selectLecture();
		return mainLectureList;
	}//selectLecture

}
