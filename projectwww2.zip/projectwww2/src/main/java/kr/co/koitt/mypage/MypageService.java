package kr.co.koitt.mypage;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

@Service
public class MypageService {
	
	@Autowired
	MypageDAO dao;

	public int apply_teacher(MypageVO vo) {
		int count = 0;
		count = dao.apply_teacher(vo);
		return count;
	}

	public List<MypageVO> TeacherApplyList() {
		List<MypageVO> list = null;
		list = dao.TeacherApplyList();
		return list;
	}//TeacherApplyList

	
	

	
		
}
