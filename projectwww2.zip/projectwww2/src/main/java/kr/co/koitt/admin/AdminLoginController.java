package kr.co.koitt.admin;

import java.io.PrintWriter;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;

import org.apache.ibatis.session.SqlSession;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;

import kr.co.koitt.join.MemberVO;

@Controller
public class AdminLoginController {

	private static final Logger logger = LoggerFactory.getLogger(AdminLoginController.class);
	
	@Autowired
	SqlSession sqlSession;
	
	@RequestMapping(value="/admin/login", method=RequestMethod.GET)
	public String loginForm() {
		logger.info("=== loginForm ===");
		return "admin/login";
	}//loginForm
	
	@RequestMapping(value="/loginpro", method=RequestMethod.GET)
	public void loginPro(AdminVO vo, HttpSession session, PrintWriter out, HttpServletRequest req) {
		logger.info("=== loginPro ===");
		session = req.getSession();
		vo = sqlSession.selectOne("AdminMapper.AdminLogin", vo);
		int cnt = 0;
		if(vo != null && vo.getAdmin_id() != null && !vo.getAdmin_id().equals("")) {
			cnt = 1;
			session.setAttribute("adminVO", vo);
		}
		out.print(cnt);
		out.close();
	}//loginPro
	
}
