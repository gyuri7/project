package kr.co.koitt.login;

public class ExamineeVO {
	
	private String examinee_no;
	private String test_no;
	private String examinee_id;
	private String examinee_pwd;
	private String examinee_name;
	private String examinee_tel;
	private String examinee_email;
	
	public String getExaminee_no() {
		return examinee_no;
	}
	public void setExaminee_no(String examinee_no) {
		this.examinee_no = examinee_no;
	}
	public String getTest_no() {
		return test_no;
	}
	public void setTest_no(String test_no) {
		this.test_no = test_no;
	}
	public String getExaminee_id() {
		return examinee_id;
	}
	public void setExaminee_id(String examinee_id) {
		this.examinee_id = examinee_id;
	}
	public String getExaminee_pwd() {
		return examinee_pwd;
	}
	public void setExaminee_pwd(String examinee_pwd) {
		this.examinee_pwd = examinee_pwd;
	}
	public String getExaminee_name() {
		return examinee_name;
	}
	public void setExaminee_name(String examinee_name) {
		this.examinee_name = examinee_name;
	}
	public String getExaminee_tel() {
		return examinee_tel;
	}
	public void setExaminee_tel(String examinee_tel) {
		this.examinee_tel = examinee_tel;
	}
	public String getExaminee_email() {
		return examinee_email;
	}
	public void setExaminee_email(String examinee_email) {
		this.examinee_email = examinee_email;
	}

}
