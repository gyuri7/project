package kr.co.koitt.subject;

import java.util.List;

import org.apache.ibatis.session.SqlSession;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

@Repository
public class SubjectDAO {
	@Autowired
	SqlSession sqlSession;
	
	public List<SubjectVO> selectSubject() {
		List<SubjectVO> listSubject = null;
		listSubject = sqlSession.selectList("SubjectMapper.selectSubject");
		return listSubject ;
	}
}
