package kr.co.koitt.subject;

public class SubjectVO {
	private String subject_no;
	private String subject_name;
	
	public String getSubject_no() {
		return subject_no;
	}
	public void setSubject_no(String subject_no) {
		this.subject_no = subject_no;
	}
	public String getSubject_name() {
		return subject_name;
	}
	public void setSubject_name(String subject_name) {
		this.subject_name = subject_name;
	}
}
