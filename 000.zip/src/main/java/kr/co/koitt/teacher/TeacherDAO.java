package kr.co.koitt.teacher;

import org.apache.ibatis.session.SqlSession;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

@Repository
public class TeacherDAO {
	
	@Autowired
	SqlSession sqlSession;

	public int teacher_insert(TeacherVO vo) {
		int count = 0;
		count = sqlSession.insert("TeacherMapper.TeacherInsert",vo);
		return count;
	}//teacher_insert

}
