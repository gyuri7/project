package kr.co.koitt.teacher;

import java.io.PrintWriter;
import java.util.List;

import org.apache.ibatis.session.SqlSession;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;

import kr.co.koitt.question.QuestionVO;
import kr.co.koitt.subject.SubjectService;
import kr.co.koitt.subject.SubjectVO;

@Controller
public class TeacherController {
	
	@Autowired
    SubjectService service;
	
	@Autowired
	TeacherService teacherService;
	
	private static final Logger logger = LoggerFactory.getLogger(TeacherController.class);
	
	@RequestMapping(value = "/teacher/lecture/lecture_insert", method = RequestMethod.GET)
	public String lecture_insert(Model model) {
		List<SubjectVO> listSubject = null;
		listSubject = service.selectSubject();
		model.addAttribute("listSubject", listSubject);
		return "teacher/lecture/lecture_insert";
	}
	
	@RequestMapping(value = "/teacher/lecture/lecture_i", method = RequestMethod.GET)
	public void teacher_insert(TeacherVO vo, PrintWriter out) {
		logger.info("teacher_insert");
		int count = 0;
		count = teacherService.teacher_insert(vo);
		out.print(count);
		out.flush();
		out.close();
	}
	
}
