package kr.co.koitt.join;

import java.io.PrintWriter;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;

import kr.co.koitt.join.MemberVO;

@Controller
public abstract class JoinControllerImpl implements JoinController {

	private static final Logger logger = LoggerFactory.getLogger(JoinControllerImpl.class);

	@Autowired
	JoinService joinService;

	@RequestMapping(value="/main/join", method=RequestMethod.GET)
	public String join(MemberVO vo) {
		logger.info("=== joinForm ===");
		joinService.JoinService(vo);
		return "main/join";
	}//joinForm
	


}//class

/*
CREATE TABLE `mbr` (
	`mbr_no` INT(11) NOT NULL AUTO_INCREMENT,
	`mbr_id` VARCHAR(30) NOT NULL,
	`mbr_nm` VARCHAR(30) NOT NULL,
	`mbr_pwd` VARCHAR(30) NOT NULL,
	`mbr_tel` VARCHAR(13) NOT NULL,
	`mbr_email` VARCHAR(50) NOT NULL,
	`mbr_level` INT(11) NOT NULL,
	`mbr_date` TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
	PRIMARY KEY (`mbr_no`)
);

CREATE TABLE `mbr_cmpn` (
	`mbr_no` INT(11) NOT NULL,
	`cmpn_reg_no` VARCHAR(12) NULL DEFAULT NULL,
	`cmpn_nm` VARCHAR(60) NULL DEFAULT NULL,
	`cmpn_ceo_nm` VARCHAR(30) NULL DEFAULT NULL,
	`cmpn_start_date` VARCHAR(10) NULL DEFAULT NULL,
	`cmpn_addr` VARCHAR(300) NULL DEFAULT NULL,
	`cmpn_desc` VARCHAR(900) NULL DEFAULT NULL,
	PRIMARY KEY (`mbr_no`)
);
*/
