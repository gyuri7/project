package kr.co.koitt.join;

public interface JoinController {

	public String join();


}
