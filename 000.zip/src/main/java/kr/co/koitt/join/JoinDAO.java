package kr.co.koitt.join;

import org.springframework.stereotype.Service;

import kr.co.koitt.join.MemberVO;

@Service
public interface JoinDAO {

	public int JoinService(MemberVO vo);



}
