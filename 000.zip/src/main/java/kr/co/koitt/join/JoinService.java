package kr.co.koitt.join;

import kr.co.koitt.join.MemberVO;

public interface JoinService {

	public int JoinService(MemberVO vo);

	
}
