package kr.co.koitt.join;

import org.apache.ibatis.session.SqlSession;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import kr.co.koitt.join.MemberVO;

@Repository
public class JoinDAOImpl implements JoinDAO {

	@Autowired
	SqlSession sqlSession;
	
	
	@Override
	public int JoinService(MemberVO vo) {
		int cnt = 0;
		cnt = sqlSession.insert("JoinMapper.JoinInsert",vo);
		return cnt;
	}





}//class
