package kr.co.koitt.join;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import kr.co.koitt.join.MemberVO;

@Service
public class JoinServiceImpl implements JoinService {

	@Autowired
	JoinDAO dao;
	
	public int JoinService(MemberVO vo) {
		int cnt = 0;
		cnt = dao.JoinService(vo);
		return cnt;
	}


}//class
