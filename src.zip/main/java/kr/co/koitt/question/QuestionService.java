package kr.co.koitt.question;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;



@Service
public class QuestionService {
	
	@Autowired
	QuestionDAO dao;

	public int QuestionInsert(QuestionVO vo) {
		int count = 0;
		count = dao.QuestionInsert(vo);
		return count;
	}// QuestionInsert
	
	public List<QuestionVO> QuestionList(){
		List<QuestionVO> list = null;
		list = dao.QuestionList();
		return list;
	}//QuestionList

	
	
}
