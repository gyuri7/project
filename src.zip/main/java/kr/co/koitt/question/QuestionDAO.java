package kr.co.koitt.question;

import java.util.List;

import org.apache.ibatis.session.SqlSession;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import kr.co.koitt.subject.SubjectVO;

@Repository
public class QuestionDAO {
	
	@Autowired
	SqlSession sqlSession;
	
	public int QuestionInsert(QuestionVO vo) {
		int count = 0;
		count = sqlSession.insert("QustionMapper.QuestionInsert",vo);
		return count;
	}//QuestionInsert

	public List<QuestionVO> QuestionList() {
		List<QuestionVO> list = null;
		list = sqlSession.selectList("QustionMapper.QuestionList");
		return list;
	}//QuestionList

	
	
}
