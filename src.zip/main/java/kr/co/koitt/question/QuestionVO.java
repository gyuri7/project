package kr.co.koitt.question;

public class QuestionVO {
	private String question_no;
	private String subject_no;
	private String subject_middle_no;
	private String question;
	private String question_answer;
	private String question_explain;

	
	public String getQuestion_no() {
		return question_no;
	}
	public void setQuestion_no(String question_no) {
		this.question_no = question_no;
	}
	public String getSubject_no() {
		return subject_no;
	}
	public void setSubject_no(String subject_no) {
		this.subject_no = subject_no;
	}
	public String getSubject_middle_no() {
		return subject_middle_no;
	}
	public void setSubject_middle_no(String subject_middle_no) {
		this.subject_middle_no = subject_middle_no;
	}
	public String getQuestion() {
		return question;
	}
	public void setQuestion(String question) {
		this.question = question;
	}
	public String getQuestion_answer() {
		return question_answer;
	}
	public void setQuestion_answer(String question_answer) {
		this.question_answer = question_answer;
	}
	public String getQuestion_explain() {
		return question_explain;
	}
	public void setQuestion_explain(String question_explain) {
		this.question_explain = question_explain;
	}
}
