package kr.co.koitt.question;

import java.io.PrintWriter;
import java.util.List;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;

import kr.co.koitt.subject.SubjectService;
import kr.co.koitt.subject.SubjectVO;


@Controller
public class QuestionController {
	
	@Autowired
	QuestionService questionservice;
	
	@Autowired
    SubjectService service;

	private static final Logger logger = LoggerFactory.getLogger(QuestionController.class);
	
	@RequestMapping(value = "/teacher/question/form_insert", method = RequestMethod.GET)
	public String formQuestionInsert(Model model) {
		List<SubjectVO> listSubject = null;
		listSubject = service.selectSubject();
		model.addAttribute("listSubject", listSubject);
		return "teacher/question/form_insert"; 
	}//formInsert
	

	@RequestMapping(value = "/teacher/question/insert", method = RequestMethod.GET)
	public void QuestionInsert(QuestionVO vo, PrintWriter out) {
		logger.info("QuestionInsert");
		int count = 0;
		count = questionservice.QuestionInsert(vo);		
		out.print(count);
		out.flush();
		out.close();

	}//QuestionInsert

}
