package kr.co.koitt.lecture;

import java.io.PrintWriter;
import java.util.List;

import javax.servlet.http.HttpSession;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.multipart.MultipartFile;

import kr.co.koitt.subject.SubjectService;
import kr.co.koitt.subject.SubjectVO;
import kr.co.koitt.util.UtilForFile;

@Controller
public class LectureController {
	
	@Autowired
    SubjectService subjectService;
	
	@Autowired
	LectureService lectureService;
	
	private static final Logger logger = LoggerFactory.getLogger(LectureController.class);
	
	@RequestMapping(value = "/lecture_write", method = RequestMethod.GET)
	public String lectureWrite(Model model, HttpSession session) {
		logger.info("lectureWrite");
		List<SubjectVO> listSubject = null;
		listSubject = subjectService.selectSubject();
		model.addAttribute("listSubject", listSubject);
//		if(UtilForSession.chkSessionLevel(session, 2) == false) {
//			return "redirect:/main/home";
//		}
		return "teacher/lecture/lecture_write";
	}//lectureWrite
	
	@RequestMapping(value = "/lecture_insert", method = RequestMethod.POST)
	public void LectureInsert(LectureVO vo, PrintWriter out) {
		logger.info("LectureInsert");
		int count = 0;
		count = lectureService.teacher_lecture_insert(vo);
		if(count == 0) {
			out.print(count);
			out.close();
			return;
		}
		//atch_file start =====
		String upFilePath = "";
		MultipartFile file = null;
		file = vo.getImage_file();
		if(vo != null && file != null && file.getOriginalFilename() != null && file.getOriginalFilename().length() > 0) {
			upFilePath = UtilForFile.fileUpByType(file, "board1", vo.getLecture_no());
			vo.setLecture_image_name(upFilePath);
		}//if
		//atch_file end =====
		out.print(count);
		out.flush();
		out.close();
	}//LectureInsert
	
	@RequestMapping(value = "/lecture_list", method = RequestMethod.GET)
	public String list(Model model, LectureVO vo) {
		logger.info("list");
		List<LectureVO> lectureList = null;
		lectureList = lectureService.lectureList();
		model.addAttribute("LectureList", lectureList);
		return "teacher/lecture/lecture_list";
	}//list
	
	@RequestMapping(value = "/lecture_detail", method = RequestMethod.GET)
	public String detail(Model model, LectureVO vo, PrintWriter out) {
		logger.info("detail");
		vo = lectureService.lecture_detail(vo);
		model.addAttribute("detailVO", vo);
		return "teacher/lecture/lecture_detail";
	}//detail
	
	@RequestMapping(value = "/lecture_modify", method = RequestMethod.GET)
	public String modifyForm(Model model, LectureVO vo) {
		logger.info("modifyForm");
		vo = lectureService.lecture_detail(vo);
		model.addAttribute("detailVO", vo);
		return "teacher/lecture/lecture_modify";
	}//modifyForm
	
	@RequestMapping(value = "/lecture_update", method = RequestMethod.POST)
	public void update(LectureVO vo, PrintWriter out) {
		logger.info("update");
		int cnt = 0;
		cnt = subjectService.lecture_update(vo);
		out.print(cnt);
		out.flush();
		out.close();
	}//update
	
	@RequestMapping(value = "/lecture_delete", method = RequestMethod.POST)
	public void delete(LectureVO vo, PrintWriter out) {
		logger.info("delete");
		int cnt = 0;
		cnt = lectureService.lecture_delete(vo);
		out.print(cnt);
		out.flush();
		out.close();
	}//delete
	
	/////////////////////////////////////////////////////////////////////////////
	//chapter
	@RequestMapping(value = "/chapter_write", method = RequestMethod.GET)
	public String chapterWrite(Model model, HttpSession session) {
		logger.info("chapter_write");
		List<SubjectVO> listSubject = null;
		listSubject = subjectService.selectSubject();
		model.addAttribute("listSubject", listSubject);
		return "teacher/lecture/chapter_write";
	}//chapterWrite
	
	@RequestMapping(value = "/chapter_insert", method = RequestMethod.POST)
	public void chapterInsert(LectureVO vo, PrintWriter out) {
		logger.info("chapterInsert");
		int count = 0;
		count = lectureService.teacher_lecture_insert(vo);
		if(count == 0) {
			out.print(count);
			out.close();
			return;
		}
		//atch_file start =====
		String upFilePath = "";
		MultipartFile file = null;
		file = vo.getImage_file();
		if(vo != null && file != null && file.getOriginalFilename() != null && file.getOriginalFilename().length() > 0) {
			upFilePath = UtilForFile.fileUpByType(file, "board1", vo.getLecture_no());
			vo.setLecture_image_name(upFilePath);
		}//if
		//atch_file end =====
		out.print(count);
		out.flush();
		out.close();
	}//chapterInsert
	
}







