package kr.co.koitt.cate;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import kr.co.koitt.subject.SubjectVO;

@Service
public class CateService {

	@Autowired
	CateDAO dao;
	
	public int cate_insert(SubjectVO vo) {
		int count = 0;
		count = dao.cate_insert(vo);
		return count;
	}//insert

	public int cate_delete(SubjectVO vo) {
		int count = 0;
		count = dao.cate_delete(vo);
		return count;
	}//delete

}
