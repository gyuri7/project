package kr.co.koitt.subject;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import kr.co.koitt.company.CompanyVO;
import kr.co.koitt.lecture.LectureVO;
import kr.co.koitt.question.QuestionVO;

@Service
public class SubjectService {
	@Autowired
	SubjectDAO dao;
	
	public List<SubjectVO> selectSubject() {
		List<SubjectVO> listSubject = null;
		listSubject = dao.selectSubject();
		return listSubject ;
	}

	public List<CompanyVO> CompanyList() {
		List<CompanyVO> CompanyList = null;
		CompanyList = dao.CompanyList();
		return CompanyList;
	}

	public int update(CompanyVO vo) {
		int successCnt = 0;
		successCnt = dao.update(vo);
		return successCnt;
	}//question_update

	public int lecture_update(LectureVO vo) {
		int cnt = 0;
		cnt = dao.lecture_update(vo);
		return cnt;
	}//lecture_update

}
