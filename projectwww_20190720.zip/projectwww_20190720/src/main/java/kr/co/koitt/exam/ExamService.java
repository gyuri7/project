package kr.co.koitt.exam;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

@Service
public class ExamService {
	
	@Autowired
	ExamDAO dao;
	
	public List<ExamVO> selectExam() {
		List<ExamVO> examList = null;
		examList = dao.selectExam();
		return examList ;
	}
}
