package kr.co.koitt;

import java.util.List;

import org.apache.ibatis.session.SqlSession;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import kr.co.koitt.lecture.LectureVO;

@Repository
public class MainLectureDAO {
	
	@Autowired
	SqlSession sqlSession;

	public List<LectureVO> selectLecture() {
		List<LectureVO> mainLectureList = null;
		mainLectureList = sqlSession.selectList("MainLectureMapper.SelectLecture");
		return mainLectureList;
	}//selectLecture

}
