package kr.co.koitt.lecture;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

@Service
public class LectureService {
	
	@Autowired
	LectureDAO dao;

	public int teacher_lecture_insert(LectureVO vo) {
		int count = 0;
		count = dao.teacher_lecture_insert(vo);
		return count;
	}//teacher_insert
	
	public List<LectureVO> lectureList() {
		List<LectureVO> lectureList = null;
		lectureList = dao.lectureList();
		return lectureList;
	}//lectureList

	public LectureVO lecture_detail(LectureVO vo) {
		vo = dao.lecture_detail(vo);
		return vo;
	}//lecture_detail

	public int lecture_update(LectureVO vo) {
		int cnt = 0;
		cnt = dao.lecture_update(vo);
		return cnt;
	}//lecture_update

	public int lecture_delete(LectureVO vo) {
		int cnt = 0;
		cnt = dao.lecture_delete(vo);
		return cnt;
	}//lecture_delete

}
