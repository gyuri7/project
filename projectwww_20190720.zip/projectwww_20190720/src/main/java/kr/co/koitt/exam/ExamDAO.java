package kr.co.koitt.exam;

import java.util.List;

import org.apache.ibatis.session.SqlSession;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

@Repository
public class ExamDAO {

	@Autowired
	SqlSession sqlSession;
	
	public List<ExamVO> selectExam() {
		List<ExamVO> examList = null;
		examList = sqlSession.selectList("ExamMapper.selectExam");
		return examList;
	}
	
}
