package kr.co.koitt.question;

import java.util.ArrayList;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

@Service
public class QuestionService {
	
	@Autowired
	QuestionDAO dao;

	public List<QuestionVO> QuestionList(){
		List<QuestionVO> list = null;
		list = dao.QuestionList();
		return list;
	}//QuestionList

	public int insertQuestion(QuestionVO vo) {
		int successCnt = 0;
		successCnt = dao.insertQuestion(vo);
		return successCnt;
	}

	public int updateQuestion(QuestionVO vo) {
		int successCnt = 0;
		successCnt = dao.updateQuestion(vo);
		return successCnt;
	}

	public int insertExample(ArrayList<ExampleVO> evoList) {
		int successCnt = 0;
		successCnt = dao.insertExample(evoList);
		return successCnt;
	}

	public QuestionVO detail(QuestionVO vo) {
		vo = dao.detail(vo);
		return vo;
	}//detail

	public int delete(QuestionVO vo) {
		int successCnt = 0;
		successCnt = dao.delete(vo);
		return successCnt;
	}

	public int update(QuestionVO vo) {
		int successCnt = 0;
		successCnt = dao.update(vo);
		return successCnt;
	}

//	public int insertExample(QuestionVO vo) {
//		int successCnt = 0;
//		successCnt = dao.insertExample(vo);
//		return successCnt;
//	}

}

	