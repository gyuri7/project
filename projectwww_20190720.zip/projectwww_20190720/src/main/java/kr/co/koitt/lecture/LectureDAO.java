package kr.co.koitt.lecture;

import java.util.List;

import org.apache.ibatis.session.SqlSession;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

@Repository
public class LectureDAO {
	
	@Autowired
	SqlSession sqlSession;

	public int teacher_lecture_insert(LectureVO vo) {
		int count = 0;
		count = sqlSession.insert("LectureMapper.LectureInsert",vo);
		return count;
	}//teacher_lecture_insert

	public List<LectureVO> lectureList() {
		List<LectureVO> lectureList = null;
		lectureList = sqlSession.selectList("LectureMapper.LectureList");
		return lectureList;
	}//lectureList

	public LectureVO lecture_detail(LectureVO vo) {
		vo = sqlSession.selectOne("LectureMapper.LectureDetail", vo);
		return vo;
	}//lecture_detail

	public int lecture_update(LectureVO vo) {
		int cnt = 0;
		cnt = sqlSession.update("LectureMapper.LectureUpdate",vo);
		return cnt;
	}//lecture_update

	public int lecture_delete(LectureVO vo) {
		int cnt = 0;
		cnt = sqlSession.delete("LectureMapper.LectureDelete",vo);
		return cnt;
	}//lecture_delete

}
