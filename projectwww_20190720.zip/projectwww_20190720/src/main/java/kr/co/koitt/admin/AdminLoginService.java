package kr.co.koitt.admin;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import kr.co.koitt.join.MemberVO;

@Service
public class AdminLoginService {

	@Autowired
	AdminLoginDAO dao;
	
	public int loginPro(AdminVO vo) {
		int cnt = 0;
		cnt = dao.loginPro(vo);
		return cnt;
	}//loginPro
	
}
