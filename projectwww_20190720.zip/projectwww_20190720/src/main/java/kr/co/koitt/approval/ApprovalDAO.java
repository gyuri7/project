package kr.co.koitt.approval;

import java.util.List;

import org.apache.ibatis.session.SqlSession;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

@Repository
public class ApprovalDAO {

	@Autowired
	SqlSession sqlSession;
	
	public List<ApprovalVO> selectTeacher() {
		List<ApprovalVO> approvalList = null;
		approvalList = sqlSession.selectList("AdminMapper.SelectTeacher");
		return approvalList;
	}//selectTeacher

	public List<ApprovalVO> selectDetail() {
		List<ApprovalVO> detailList = null;
		detailList = sqlSession.selectList("AdminMapper.selectDetail");
		return detailList;
	}//selectDetail

}
